from fastapi import FastAPI
from pydantic import BaseModel
from usp.tree import sitemap_tree_for_homepage
from fastapi import FastAPI
from starlette.exceptions import HTTPException as StarletteHTTPException

app=FastAPI()

class Item(BaseModel):
    base_url:str

@app.post("/sitemap")
def sitemap_url_with_timeout(item:Item):
    try:
        print("Inside using_sitemap ---------->", item.base_url)
        tree =  sitemap_tree_for_homepage(item.base_url)
        urls = [page.url for page in tree.all_pages()]
        url_list = list(set(urls))
        
        print("----------------------------------")
        print(url_list)
        print("Length of url ---------->", len(url_list))
        return url_list
    except TimeoutError as e:
        print(e)
       
import uvicorn
if __name__=="__main__":
    uvicorn.run(app,host="0.0.0.0", port=4009)