from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from sentence_transformers import SentenceTransformer
import uvicorn
import re
from pydantic import BaseModel
from fastapi import FastAPI
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from sentence_transformers import SentenceTransformer
import uvicorn
import re
import pickle
from sklearn.metrics.pairwise import cosine_similarity
import requests
import os
import pandas as pd
import re
import pickle
from sklearn.metrics.pairwise import cosine_similarity
import os
from llama_index import VectorStoreIndex, SimpleDirectoryReader, ServiceContext
from llama_index.vector_stores import ChromaVectorStore
from llama_index.storage.storage_context import StorageContext
from llama_index.embeddings import HuggingFaceEmbedding
import chromadb
from llama_index.node_parser import SimpleNodeParser
from llama_index.indices.vector_store.retrievers import VectorIndexAutoRetriever
import llama_index
from llama_index.indices.vector_store.retrievers import VectorIndexRetriever
from llama_index.query_engine.retriever_query_engine import RetrieverQueryEngine

import os

# System call
os.system("")

# Class of different styles
class style():
    BLACK = '\033[30m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'
    UNDERLINE = '\033[4m'
    RESET = '\033[0m'


app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Set the allowed origins. You can customize this based on your needs.
    allow_credentials=True,  # Set to True if your API allows credentials (e.g., cookies, authentication headers)
    allow_methods=["*"],  # Set the allowed HTTP methods. You can customize this based on your needs.
    allow_headers=["*"],  # Set the allowed HTTP headers. You can customize this based on your needs.
)
class Data(BaseModel):
    query: str
    domainId:int
    websiteId:str

model = SentenceTransformer('all-mpnet-base-v2')
model = model.to('cpu')

qn_embeddings = pickle.load(open('Agent_greeting_question_nov_23_v1.pkl', 'rb'))
intents = pickle.load(open('Agent_greeting_intent_nov_23_v1.pkl', 'rb'))
bot_output = pickle.load(open('Agent_greeting_answer_nov_23_v1.pkl', 'rb'))

embed_model = HuggingFaceEmbedding(model_name="BAAI/bge-small-en-v1.5",device="cpu")
service_context = ServiceContext.from_defaults(embed_model=embed_model,llm = None,chunk_size=300)
embed_model1 = HuggingFaceEmbedding(model_name="thenlper/gte-base",device="cpu")
#service_context1 = ServiceContext.from_defaults(embed_model=embed_model1,llm = None,chunk_size=300)


import requests
class CustomEmbeddingModel:
    def __init__(self, model_name):
        super().__init__()
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModel.from_pretrained(model_name)

    # def save_vectors_to_faiss_db(self, vectors, database_path):
    #     vectors_np = np.array(vectors, dtype=np.float32)
    #     index = faiss.IndexFlatIP(vectors_np.shape[1])
    #     faiss.normalize_L2(vectors_np)
    #     index.add(vectors_np)
    #     os.makedirs(os.path.dirname(database_path), exist_ok=True)
    #     try:
    #         faiss.write_index(index, database_path)
    #         print(f"Faiss database saved successfully to {database_path}")
    #     except Exception as e:
    #         print(f"Error saving Faiss database: {e}")

    def encode_text(self, text):
        inputs = self.tokenizer(text, return_tensors="pt", padding=True, truncation=True)
        outputs = self.model(**inputs)
        vectors = outputs.last_hidden_state.mean(dim=1).tolist()
        return vectors

    def load_faissdb(self,db_path, user_input, segmented_text):
        index = faiss.read_index(db_path)
        input_text_vector = self.encode_text(user_input)
        input_text_vector = np.array(input_text_vector, dtype=np.float32)
        distances, indices = index.search(np.array(input_text_vector), k=3)
        similar_texts = [segmented_text[i] for i in indices[0]]
        return similar_texts



def greetings_data(input_text):
    #preprocesing the input data
    req = re.sub(r'[^A-Za-z0-9]', ' ', input_text.lower())
    req = re.sub(r"\s+", ' ', req)

    # Encode the text to get embeddings
    req_embeddings = model.encode([req]).reshape(1, -1)

    # Compute similarity
    cosine_sim = cosine_similarity(qn_embeddings, req_embeddings)
    cosine_sim = [(idx, item) for idx, item in enumerate(cosine_sim)]
    sim_scores = sorted(cosine_sim, key=lambda x: x[1], reverse=True)

    # Return response of the top most similar question
    top_score = sim_scores[0]
    g = top_score[1]
    qn_indice = top_score[0]
    bot_response=bot_output.iloc[qn_indice]
    intent = intents.iloc[qn_indice]

    return {"g_score":g,"result":bot_response,"intent":intent}


def csv_data(input_text,db_path_csv):
    print("\ndb_path_csv-------------------------",db_path_csv)
    directory_name = db_path_csv
    em_pkl=pickle.load(open(f'{directory_name}/query_embedding.pkl', 'rb'))
    Answer=pickle.load(open(f'{directory_name}/Answer.pkl', 'rb'))
    req = re.sub(r'[^A-Za-z0-9]', ' ', input_text.lower())
    req = re.sub(r"\s+", ' ', req)
    req_embeddings = model.encode(req).reshape(1,-1)

    cosine_sim = cosine_similarity(em_pkl, req_embeddings)
    cosine_sim = [(idx, item) for idx, item in enumerate(cosine_sim)]
    sim_scores = sorted(cosine_sim, key=lambda x: x[1], reverse=True)
    top_score = sim_scores[0]
    g = top_score[1]
    qn_indice = top_score[0]
    que_ans = Answer[qn_indice]

    return {"result":que_ans,"intent":"faq","g_score":float(g)}


def doc_data(input_text,db_path_docs):
    db_docs = chromadb.PersistentClient(path=db_path_docs)
    chroma_collection = db_docs.get_or_create_collection("quickstart")
    docs_vector_store = ChromaVectorStore(chroma_collection=chroma_collection)
    docs_index = VectorStoreIndex.from_vector_store(
        docs_vector_store,
        service_context=service_context,
        show_progress=True
    )
    docs_retriever = llama_index.indices.vector_store.retrievers.VectorIndexRetriever(
            index=docs_index,
            similarity_top_k=4
    )
    
    docs_result = docs_retriever.retrieve(input_text)
    g = docs_result[0].score
    result = "" 
    cnt = 0
    try:
        for i in range(4):
            result += docs_result[i].node.text
            cnt+=1
    except:
        print("no of chunks from doc------------------------------> ",cnt)
        cnt = 0

    b = "others"
    response = {'result': result,'intent':b,"g_score":float(g)}
    return response


def web_data(input_text,db_path_web,chunk_size = 2):
    service_context = ServiceContext.from_defaults(embed_model=embed_model1,llm = None,chunk_size=300)
    db_web = chromadb.PersistentClient(path=db_path_web)
    chroma_collection = db_web.get_or_create_collection("quickstart")
    web_vector_store = ChromaVectorStore(chroma_collection=chroma_collection)
    web_index = VectorStoreIndex.from_vector_store(
        web_vector_store,
        service_context=service_context,
        show_progress=True
    )

    web_retriever = llama_index.indices.vector_store.retrievers.VectorIndexRetriever(
            index=web_index,
            similarity_top_k=4
    )  
    web_result = web_retriever.retrieve(input_text)
    g = web_result[0].score 
    result = ""
    cnt = 0
    try:
        for i in range(chunk_size):
            result += web_result[i].node.text 
            cnt+=1
    except:
        print("no of chunks from web------------------------------> ",cnt)
        cnt = 0

    b = "others"
    response = {'result': result,'intent':b,"g_score":float(g)}
    return response


@app.post("/knowledge_data")
def search(datas:Data):

    try:
        input_text=datas.query
        print(style.MAGENTA+"input_text---->",input_text)
        dom_id=datas.domainId
        print(style.MAGENTA+"dom_id----->",dom_id)
        web_id=datas.websiteId
        print(style.MAGENTA+"web_id----->",web_id,"\n")

        db_path_csv=f"pkl_live_server/{dom_id}/{web_id}"
        db_path_docs=f"merged_embedded_article/{dom_id}/{web_id}"
        db_path_web=f"embedded_data_v2/{dom_id}/{web_id}"

        is_csv_exist = os.path.exists(db_path_csv)
        is_doc_exist = os.path.exists(db_path_docs)
        is_web_exist = os.path.exists(db_path_web)


        print(style.YELLOW+"Is web_db present -------->",is_web_exist)
        print(style.YELLOW+"Is doc_db present -------->",is_doc_exist)
        print(style.YELLOW+"Is csv_db present -------->",is_csv_exist)


        greeting_response = greetings_data(input_text)
        greet_score = greeting_response["g_score"]
        greet_ans = greeting_response["result"]
        greet_intent = greeting_response["intent"]

        if greet_score > 0.8 and greet_intent != "others":
            if greet_intent == "Live_Agent":
                greet_intent = "transfer_live_agent"
            response= {"result":greet_ans,"intent":greet_intent,'domainId': dom_id,'websiteId':web_id,"g_score":float(greet_score)}
            print(style.GREEN+"\nReponse-------------------------->",response,"\n")
            return response

        elif is_csv_exist and is_doc_exist and is_web_exist:
            csv_response = csv_data(input_text,db_path_csv)
            doc_response = doc_data(input_text,db_path_docs)
            web_response = web_data(input_text,db_path_web)

            csv_context = csv_response["result"]
            doc_context = doc_response["result"]
            web_context = web_response["result"]

            csv_score = csv_response["g_score"]
            doc_score = doc_response["g_score"]
            web_score = web_response["g_score"]

            print(style.MAGENTA+"\ncsv context---------------->",csv_context,"\n")
            print(style.MAGENTA+"\nweb context---------------->",web_context,"\n")
            print(style.MAGENTA+"\ndoc context---------------->",doc_context,"\n")

            if csv_score > 0.8:
                response= {"result":csv_context,"intent":"faq",'domainId': dom_id,'websiteId':web_id,"g_score":float(csv_score),"csv_score":csv_score,"web_score":None,"doc_score":None}
                print(style.GREEN+"\nReponse-------------------------->",response,"\n")
                return response

            context = csv_context + "\n" +web_context +"\n" + doc_context
            response= {"result":context,"intent":"others",'domainId': dom_id,'websiteId':web_id,"g_score":float(0.9),"csv_score":csv_score,"web_score":web_score,"doc_score":doc_score}
            print(style.GREEN+"\nReponse-------------------------->",response,"\n")
            return response

        elif is_csv_exist and is_doc_exist:
            csv_response = csv_data(input_text,db_path_csv)
            doc_response = doc_data(input_text,db_path_docs)

            csv_context = csv_response["result"]
            doc_context = doc_response["result"]

            csv_score = csv_response["g_score"]
            doc_score = doc_response["g_score"]

            print(style.MAGENTA+"\ncsv context---------------->",csv_context,"\n")
            print(style.MAGENTA+"\ndoc context---------------->",doc_context,"\n")

            if csv_score > 0.8:
                response= {"result":csv_context,"intent":"faq",'domainId': dom_id,'websiteId':web_id,"g_score":float(csv_score),"csv_score":csv_score,"web_score":None,"doc_score":None}
                print(style.GREEN+"\nReponse-------------------------->",response,"\n")
                return response

            context = csv_context +"\n"+ doc_context
            response= {"result":context,"intent":"others",'domainId': dom_id,'websiteId':web_id,"g_score":float(0.9),"csv_score":csv_score,"web_score":None,"doc_score":doc_score}
            print(style.GREEN+"\nReponse-------------------------->",response,"\n")
            return response
        
        elif is_csv_exist and is_web_exist:
            csv_response = csv_data(input_text,db_path_csv)
            web_response = web_data(input_text,db_path_web,chunk_size=3)

            csv_context = csv_response["result"]
            web_context = web_response["result"]

            csv_score = csv_response["g_score"]
            web_score = web_response["g_score"]

            print(style.MAGENTA+"\ncsv context---------------->",csv_context,"\n")
            print(style.MAGENTA+"\nweb context---------------->",web_context,"\n")

            if csv_score > 0.8:
                response= {"result":csv_context,"intent":"faq",'domainId': dom_id,'websiteId':web_id,"g_score":float(csv_score),"csv_score":csv_score,"web_score":None,"doc_score":None}
                print(style.GREEN+"\nReponse-------------------------->",response,"\n")
                return response


            context = csv_context +"\n"+ web_context
            response= {"result":context,"intent":"others",'domainId': dom_id,'websiteId':web_id,"g_score":float(0.9),"csv_score":csv_score,"web_score":web_score,"doc_score":None}
            print(style.GREEN+"\nReponse-------------------------->",response,"\n")
            return response
        
        elif is_doc_exist and is_web_exist:
            doc_response = doc_data(input_text,db_path_docs)
            web_response = web_data(input_text,db_path_web)

            doc_context = doc_response["result"]
            web_context = web_response["result"]

            doc_score = doc_response["g_score"]
            web_score = web_response["g_score"]

            print(style.MAGENTA+"\nweb context---------------->",web_context,"\n")
            print(style.MAGENTA+"\ndoc context---------------->",doc_context,"\n")
           
            context = web_context +"\n" + doc_context
            response= {"result":context,"intent":"others",'domainId': dom_id,'websiteId':web_id,"g_score":float(0.9),"csv_score":None,"web_score":web_score,"doc_score":doc_score}
            print(style.GREEN+"\nReponse-------------------------->",response,"\n")
            return response
        
        elif is_csv_exist:
            csv_response = csv_data(input_text,db_path_csv)
            csv_ans = csv_response["result"]
            csv_score = csv_response["g_score"]

            print(style.MAGENTA+"\ncsv context---------------->",csv_ans,"\n")

            if csv_score > 0.55 and csv_score < 0.8:
                response= {"result":csv_ans,"intent":"others",'domainId': dom_id,'websiteId':web_id,"g_score":float(0.9),"csv_score":csv_score,"web_score":None,"doc_score":None}
                print(style.GREEN+"\nReponse-------------------------->",response,"\n")
                return response
            
            elif csv_score > 0.8:
                response= {"result":csv_ans,"intent":"faq",'domainId': dom_id,'websiteId':web_id,"g_score":float(csv_score),"csv_score":csv_score,"web_score":None,"doc_score":None}
                print(style.GREEN+"\nReponse-------------------------->",response,"\n")
                return response
            
            else:
                response = {'result': "Apologize, I am not trained for the query you have asked for.",'intent':"faq",'domainId': dom_id,"g_score":float(0.0),"csv_score":csv_score,"web_score":None,"doc_score":None}
                print(style.GREEN+"\nReponse-------------------------->",response,"\n")
                return response

        elif is_doc_exist:
            doc_response = doc_data(input_text,db_path_docs)
            doc_context = doc_response["result"]
            doc_score = doc_response["g_score"]

            print(style.MAGENTA+"\ndoc context---------------->",doc_context,"\n")

            response= {"result":doc_context,"intent":"others",'domainId': dom_id,'websiteId':web_id,"g_score":float(0.9),"csv_score":None,"web_score":None,"doc_score":doc_score}
            print(style.GREEN+"\nReponse-------------------------->",response,"\n")
            return response
        
        elif is_web_exist:
            web_response = web_data(input_text,db_path_web,chunk_size=3)
            web_context = web_response["result"]
            web_score = web_response["g_score"]

            print(style.MAGENTA+"\ndoc context---------------->",web_context,"\n")

            response= {"result":web_context,"intent":"others",'domainId': dom_id,'websiteId':web_id,"g_score":float(0.9),"csv_score":None,"web_score":web_score,"doc_score":None}
            print(style.GREEN+"\nReponse-------------------------->",response,"\n")
            return response
        
        else:
            response = {'result': "Apologize, I am not trained for the query you have asked for.",'intent':"others",'domainId': dom_id,"g_score":float(0.0),"csv_score":None,"web_score":None,"doc_score":None}
            print(style.RED+"\nReponse-------------------------->",response,"\n")
            return response
        

    except KeyboardInterrupt as k:
        print(k)
        exit()

    except Exception as e:
        print(e)
        response = {'result': "Apologize, I am not trained for the query you have asked for.",'intent':"others",'domainId': dom_id,"g_score":float(0.0),"csv_score":None,"web_score":None,"doc_score":None}
        print(style.RED+"\nReponse-------------------------->",response,"\n")
        return response


if __name__ == "__main__":
    uvicorn.run(app, host="10.150.3.150", port=5099)







    

