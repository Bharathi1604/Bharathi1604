import requests
import csv
import pandas as pd
import numpy as np
import re
import redis
import json
import pickle
import random
import torch
from sentence_transformers import SentenceTransformer, util
from sklearn.metrics.pairwise import cosine_similarity
from infer_11_10_new import ent
import concurrent.futures

model = SentenceTransformer('all-mpnet-base-v2')
model = model.to('cpu')
block_words = ["I don't know", "i don't know", "i don't Know","not able to provide the information","i don't have enough information","i don't have access to the information","i don't know","not able to provide the information","not able to provide the information","i don't have enough information","i don't have access to the information"]
rand_ans=[" Sorry, I can't provide a relevant answer at the moment. If you have another question or need assistance with something else, feel free to ask. Thank you!"," Apologies, I can't generate a response for that right now. Feel free to ask another question or explore a different topic."," I'm currently unable to provide an answer to that. If you have a different question in mind, go ahead and ask!"," Sorry, I can't generate a response for your question. If you have another topic or question in mind, feel free to let me know."," I can't address that question at the moment. If there's something else on your mind or another topic you're interested in, feel free to ask."," Unfortunately, I can't provide the information you're looking for right now. If you have another question or a different topic in mind, please share!"," I'm sorry, but I can't offer a response to that inquiry. If there's another question or topic you'd like to explore, feel free to bring it up."]
# csv_filename_2="/home/vectone/Downloads/Delight_uk_variations_DB_9.xlsx"

csv_filename_2="Delight_uk_variations_DB_9.xlsx"
print("local dataset: ",csv_filename_2 )
df = pd.read_excel(csv_filename_2)

print(len(df))
clean_question = []
for i in range(len(df['question'])):
    new_string = re.sub(r'[^A-Za-z0-9]', ' ', str(df['question'][i]).lower())
    new_string = re.sub(r"\s+", ' ', new_string)
    clean_question.append(new_string)


qn_embeddings = model.encode(clean_question)  #-------------- temp

def read_root(questions,domainId,web_id,company_name,industry_type):
    print()
    print()
    print("User Question -- ",questions)
    print()
    print()
    ent_user=ent(questions)
    ANS_QUE = {"User_input_Entity":ent_user}
    print("ANS_QUE",ANS_QUE)
    req = re.sub(r'[^A-Za-z0-9]', ' ', questions.lower())
    req = re.sub(r"\s+", ' ', req)

    req_embeddings = model.encode([req]).reshape(1, -1)
    cosine_sim = cosine_similarity(qn_embeddings, req_embeddings)
    cosine_sim = [(idx, item) for idx, item in enumerate(cosine_sim)]
    sim_scores = sorted(cosine_sim, key=lambda x: x[1], reverse=True)

    top_score = sim_scores[0]
    g = top_score[1]
    print()
    print("g value  ---- ")
    print(g)
    print()
    print()
    if g > 0.7:
        qn_indice = top_score[0]
        a=df['answer'].iloc[qn_indice]
        b=df['intent'].iloc[qn_indice]
        ans={"que_answer":a,"ans_intent":b,"unresponse_query":questions,"unresponse_key":0}
        ANS_QUE.update(ans)
        return ANS_QUE
    else:
        print("questions -- ",questions)
        print("domainId -- ",domainId)
        print("websiteId -- ",web_id)
        print("company_name -- ",company_name)
        payload_1 = {"query": questions,"domainId":domainId,"websiteId":web_id}
        response = requests.post("http://10.150.3.150:5099/knowledge_data", json=payload_1)
        response_1=response.json()
        a=response_1["intent"]
        print("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
        g_score=response_1["g_score"]
        print("--------------------------------------------",g_score)
        if a == "faq":
            b=response_1["result"]
            Final_data_2={"ans_intent":"others","que_answer":b,"domainId":domainId,"websiteId":web_id,"unresponse_query":questions,"unresponse_key":0}
            ANS_QUE.update(Final_data_2)
            return ANS_QUE

        elif 0.5 < g_score and g_score < 1.2:

            if a == "others":
                print("111111111111111111")
                intent_text= response_1['intent']
                text=response_1['result']
                payload_2={"message_content":questions,'content':text,"company_name":company_name,"domain":industry_type}
                print("Prompt_input_payload",payload_2)
                print()
                try:
                    response_2=requests.post("http://46.43.144.145:8078/rulebased_bot",json=payload_2,timeout=30)
                    final_data=response_2.json()
                    print("final_data --- ",final_data)
                    Final_response=final_data["response"]
                    print("Model Output --------",Final_response)
                    print()

                    if Final_response == "I don't know" or Final_response == "i don't know" or "We don't know" in Final_response or "we don't know" in Final_response:
                        Final_response = random.choice(rand_ans)
                        Final_data={"ans_intent":intent_text,"que_answer":Final_response,"domainId":domainId,"websiteId":web_id,"unresponse_query":questions,"unresponse_key":1}
                        print(Final_data)
                        ANS_QUE.update(Final_data)
                        return ANS_QUE


                    else:
                        Final_response = Final_response.replace("They","We").replace("they","we").replace("themself","ourself").replace("Themself","Ourself").replace('My','Our')
                        Final_data={"ans_intent":intent_text,"que_answer":Final_response,"domainId":domainId,"websiteId":web_id,"unresponse_query":questions,"unresponse_key":0}
                    print(Final_data)
                    ANS_QUE.update(Final_data)            
                    return ANS_QUE
                except requests.exceptions.Timeout:
                    Final_response="Sorry,something went wrong.we are unable to process your request."


                    Final_data={"ans_intent":intent_text,"que_answer":Final_response,"domainId":domainId,"websiteId":web_id,"unresponse_query":questions,"unresponse_key":1}
                    print(Final_data)
                    ANS_QUE.update(Final_data)
                    return ANS_QUE
                    
            else:
                print("222222222222222222222222")
                intent_text_1=response_1["intent"]
                response_final =response_1["result"]
                response_final = response_final.replace("abcxyz",company_name)
                Final_data_2={"ans_intent":intent_text_1,"que_answer":response_final,"domainId":domainId,"websiteId":web_id,"unresponse_query":questions,"unresponse_key":0}
                print(Final_data_2)
                ANS_QUE.update(Final_data_2)
                return ANS_QUE
        else:
            Final_response=random.choice(rand_ans)
            Final_data={"ans_intent":intent_text,"que_answer":Final_response,"domainId":domainId,"websiteId":web_id,"unresponse_query":questions,"unresponse_key":1}
            print(Final_data)
            ANS_QUE.update(Final_data)
            return ANS_QUE




rc = redis.Redis(
    host='10.150.0.250',
    port=6379,
    db=0,
    password='vectone250',
    decode_responses=True
)

def get_response(data):
    final_data = data[0]
    stream = data[1]
    msg_id = data[2]

    print("333333333333333333333333",final_data)
    bot_id = final_data['domainId']
    print(final_data, "hhhhhh")
    try:
        if bot_id == 11226:
            print("11111111111111111111111111111111111111")
            print("444444444444444444444444")
            ses = final_data["sessionId"]
            socketId = final_data["socketId"]
            datas = {'sessionId': ses,'socketId':socketId}
            questions = final_data["question"]
            domainId=final_data["domainId"]
            web_id=final_data["websiteId"]
            company_name="Delight mobile"
            industry_type = "telecommunication"
            final_data2 = read_root(questions,domainId,web_id,company_name,industry_type=industry_type)
            datas.update(final_data2)
            print(datas)
            print("55555555555555555555555555555")
            x=rc.xadd('TEMP_BASE_STREAM_NAME_RES1',{"message":json.dumps(datas)},id='*')
            print("XADD-DATA----ID",x)
            rc.xack(stream, 'REQUEST_GROUP1', msg_id)
            print("666666666666666666666666666")
            print("rpush success delight ---")
            print(f"Acknowledged{msg_id} in this{stream} ")
            c=rc.xtrim("TEMP_BASE_STREAM_NAME_REQ1", maxlen=100)
            stream_length_after = rc.xlen("TEMP_BASE_STREAM_NAME_REQ1")
            print("Stream length after trimming:", stream_length_after)
            print()
        else:
            ses = final_data["sessionId"]
            domainId=final_data["domainId"]
            questions = final_data["question"]
            web_id=final_data["websiteId"]
            socketId = final_data["socketId"]
            try:
                company_name=final_data["company_name"]
                if company_name == None:
                    company_name =""
            except:
                    company_name = ""

            try:
                industry_type=final_data["industry_type"]
                if industry_type == None:
                    industry_type =""
            except:
                    industry_type = ""


            print("questions -- ",questions)
            print("domainId -- ",domainId)
            print("websiteId -- ",web_id)
            print("company_name -- ",company_name)
            print("socketId-----",socketId)
            payload_1 = {"query": questions,"domainId":domainId,"websiteId":web_id}
            print("payload_1----------------",payload_1)
            response = requests.post("http://10.150.3.150:5099/knowledge_data", json=payload_1)
            response_1=response.json()
            a=response_1["intent"]
            print("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
            g_score=response_1["g_score"]
            print("--------------------------------------------",g_score)
            print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
            
            if a == "faq":
                    b=response_1["result"]
                    Final_data_2={"ans_intent":"others","que_answer":b,"sessionId":ses,"socketId":socketId,"domainId":domainId,"websiteId":web_id,"unresponse_query":questions,"unresponse_key":0}
                    print(Final_data_2)
                    print()
                    x=rc.xadd('TEMP_BASE_STREAM_NAME_RES1',{"message":json.dumps(Final_data_2)},id='*')
                    print("XADD-DATA----ID",x)
                    print("rpush success Templates bot  ---")
                    rc.xack(stream, 'REQUEST_GROUP1', msg_id)
                    print(f"Acknowledged{msg_id} in this{stream} ")
                    c=rc.xtrim("TEMP_BASE_STREAM_NAME_REQ1", maxlen=100)
                    stream_length_after = rc.xlen("TEMP_BASE_STREAM_NAME_REQ1")
                    print("Stream length after trimming:", stream_length_after)
                    print()
                    print()


            elif 0.5 < g_score and g_score < 1.1:

                if a == "others":
                    print("111111111111111111")
                    intent_text= response_1['intent']
                    text=response_1['result']
                    payload_2={"message_content":questions,'content':text,"company_name":company_name,"domain":industry_type}
                    print("Prompt_input_payload",payload_2)
                    print()
                    try:
                        response_2=requests.post("http://46.43.144.145:8078/rulebased_bot",json=payload_2,timeout=30)
                        final_data=response_2.json()
                        print("final_data --- ",final_data)
                        Final_response=final_data["response"]
                        print("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^")
                        print("Model Output --------",Final_response)
                        print()
                        
                        if Final_response == "I don't know" or Final_response == "i don't know" or "We don't know" in Final_response or "we don't know" in Final_response:
                            Final_response = random.choice(rand_ans)
                            Final_data={"ans_intent":intent_text,"que_answer":Final_response,"sessionId":ses,"socketId":socketId,"domainId":domainId,"websiteId":web_id,"unresponse_query":questions,"unresponse_key":1}

                        else:
                            Final_response = Final_response.replace("They","We").replace("they","we").replace("themself","ourself").replace("Themself","Ourself").replace('My','Our')
                            Final_data={"ans_intent":intent_text,"que_answer":Final_response,"sessionId":ses,"socketId":socketId,"domainId":domainId,"websiteId":web_id,"unresponse_query":questions,"unresponse_key":0}
                            print(Final_data)
                        print()
                        x=rc.xadd('TEMP_BASE_STREAM_NAME_RES1',{"message":json.dumps(Final_data)},id='*')
                        print("XADD-DATA----ID",x)
                        print("rpush success Templates bot ---")
                        rc.xack(stream, 'REQUEST_GROUP1', msg_id)
                        print(f"Acknowledged{msg_id} in this{stream} ")
                        c=rc.xtrim("TEMP_BASE_STREAM_NAME_REQ1", maxlen=100)
                        stream_length_after = rc.xlen("TEMP_BASE_STREAM_NAME_REQ1")
                        print("Stream length after trimming:", stream_length_after)
                        print()
                        print()
                    except requests.exceptions.Timeout:
                        Final_response="Sorry,something went wrong.we are unable to process your request."
                        Final_data={"ans_intent":intent_text,"que_answer":Final_response,"sessionId":ses,"socketId":socketId,"domainId":domainId,"websiteId":web_id,"unresponse_query":questions,"unresponse_key":1}
                        print(Final_data)
                        print()
                        x=rc.xadd('TEMP_BASE_STREAM_NAME_RES1',{"message":json.dumps(Final_data)},id='*')
                        print("XADD-DATA----ID",x)
                        print("rpush success Templates bot ---")
                        rc.xack(stream, 'REQUEST_GROUP1', msg_id)
                        print(f"Acknowledged{msg_id} in this{stream} ")
                        c=rc.xtrim("TEMP_BASE_STREAM_NAME_REQ1", maxlen=100)
                        stream_length_after = rc.xlen("TEMP_BASE_STREAM_NAME_REQ1")
                        print("Stream length after trimming:", stream_length_after)
                        print()
                        print()
                        
                else:
                    print("222222222222222222222222")
                    intent_text_1=response_1["intent"]
                    response_final =response_1["result"]
                    response_final = response_final.replace("abcxyz",company_name)
                    Final_data_2={"ans_intent":intent_text_1,"que_answer":response_final,"sessionId":ses,"socketId":socketId,"domainId":domainId,"websiteId":web_id,"unresponse_query":questions,"unresponse_key":0}
                    print(Final_data_2)
                    print()
                    x=rc.xadd('TEMP_BASE_STREAM_NAME_RES1',{"message":json.dumps(Final_data_2)},id='*')
                    print("XADD-DATA----ID",x)
                    print("rpush success Templates bot  ---")
                    rc.xack(stream, 'REQUEST_GROUP1', msg_id)
                    print(f"Acknowledged{msg_id} in this{stream} ")
                    c=rc.xtrim("TEMP_BASE_STREAM_NAME_REQ1", maxlen=100)
                    stream_length_after = rc.xlen("TEMP_BASE_STREAM_NAME_REQ1")
                    print("Stream length after trimming:", stream_length_after)
                    print()
                    print()
            else:
                Final_response=random.choice(rand_ans)
                Final_data={"ans_intent":intent_text,"que_answer":Final_response,"sessionId":ses,"socketId":socketId,"domainId":domainId,"websiteId":web_id,"unresponse_query":questions,"unresponse_key":1}
                print(Final_data)
                print()
                x=rc.xadd('TEMP_BASE_STREAM_NAME_RES1',{"message":json.dumps(Final_data)},id='*')
                print("rpush success Templates bot ---")
                print("XADD-DATA----ID",x)
                rc.xack(stream, 'REQUEST_GROUP1', msg_id)
                print(f"Acknowledged{msg_id} in this{stream} ")
                c=rc.xtrim("TEMP_BASE_STREAM_NAME_REQ1", maxlen=100)
                stream_length_after = rc.xlen("TEMP_BASE_STREAM_NAME_REQ1")
                print("Stream length after trimming:", stream_length_after)
                print()
                print()
    except :
        print(f"Error:{e}")

rc.delete("TEMP_BASE_STREAM_NAME_REQ1")
rc.xgroup_create('TEMP_BASE_STREAM_NAME_REQ1', 'REQUEST_GROUP1', id='0', mkstream=True)
while True:
    try:
        messages = rc.xreadgroup('REQUEST_GROUP1', 'consumer1', {'TEMP_BASE_STREAM_NAME_REQ1': '>'})
        for stream, message in messages:
            for msg_id, data in message:
                print(f"Received message {msg_id} from stream ---{stream}----: {data}")
                stream_length_before = rc.xlen("TEMP_BASE_STREAM_NAME_REQ1")
                print("Stream length before trimming:", stream_length_before)
                with concurrent.futures.ThreadPoolExecutor() as executor:
                    final_data = json.loads(data["message"])
                    executor.submit(get_response,(final_data,stream,msg_id))
                
    except Exception as e:
        print(e)

    except KeyboardInterrupt:
        exit()


