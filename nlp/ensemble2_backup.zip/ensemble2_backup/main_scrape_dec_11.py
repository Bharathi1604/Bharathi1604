from llama_index.storage.storage_context import StorageContext
from semantic_text_splitter import HuggingFaceTextSplitter
from semantic_text_splitter import CharacterTextSplitter
from llama_index import VectorStoreIndex,ServiceContext
from llama_index.vector_stores import ChromaVectorStore
from llama_index.embeddings import HuggingFaceEmbedding
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer
from fastapi.middleware.cors import CORSMiddleware
from transformers import AutoModel, AutoTokenizer
from playwright.async_api import async_playwright
from usp.tree import sitemap_tree_for_homepage
from urllib.parse import urlparse, urljoin
from typing import Optional, List
from tokenizers import Tokenizer
from pydantic import BaseModel
from datetime import datetime
from bs4 import BeautifulSoup
from codetiming import Timer
from fastapi import FastAPI
from copy import copy
import llama_index
import numpy as np
import unicodedata
import threading
import chromadb
import requests
import asyncio
import logging
import uvicorn
import torch
import redis
import time
import json
import os
import gc
import re

# redis_cli = Redis(host="localhost",port=6379)

# rc = redis.Redis(
#    host='localhost',
#    port=6379,
#    db=0,
#    decode_responses=True
# )

rc = redis.Redis(
    host='10.150.0.250',
    port=6379,
    db=0,
    password='vectone250',
    decode_responses=True
)

logger = logging.getLogger(__name__)
TIME_OUT = 120000

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Set the allowed origins. You can customize this based on your needs.
    allow_credentials=True,  # Set to True if your API allows credentials (e.g., cookies, authentication headers)
    allow_methods=["*"],  # Set the allowed HTTP methods. You can customize this based on your needs.
    allow_headers=["*"],  # Set the allowed HTTP headers. You can customize this based on your needs.
)

os.environ["TOKENIZERS_PARALLELISM"] = "false"

def nfkc_normalize(text: str) -> str:
    return unicodedata.normalize("NFKC", text)

chroma_client = chromadb.EphemeralClient()

class CustomEmbeddingModel:
    def __init__(self, model_name):
        self.model = SentenceTransformer(model_name,device = "cpu")

    @classmethod
    def save_vectors_to_chromadb(cls, embeddings, documents, db_path):
        client = chromadb.PersistentClient(path=os.path.abspath(db_path))
        collection = client.create_collection("testdb1")
    
        collection.add(embeddings=embeddings, documents=documents, ids=[f"id{i}" for i in range(1, len(embeddings) + 1)])
        print(f"ChromaDB saved successfully to {db_path}")

    def encode_text(self, text):
        embeddings = self.model.encode(text, convert_to_tensor=True, show_progress_bar = True)
        return embeddings.tolist()

    def segment_text(file_contents, chunk_size):
        tokenizer = Tokenizer.from_pretrained("bert-base-uncased")
        splitter = HuggingFaceTextSplitter(tokenizer, trim_chunks=False)

        sentences = splitter.chunks(file_contents, chunk_size)

        result_chunks = []
        current_chunk = ""
        for i in range(len(sentences)):
            current_chunk += f" {sentences[i]}"
            if current_chunk.count(" ") >= 256:
                result_chunks.append(current_chunk)
                current_chunk = f"{sentences[i-2]} {sentences[i-1]} {sentences[i]}"
        return result_chunks

class URLIngestion:

    def __init__(self, base_url):
        self.base_url = base_url
        self.url = self.remove_language_code(base_url)

    def remove_language_code(self,url):
        print("\nBefore removing language code-----------------------",url)
        parsed_url = urlparse(url)

        path_components = parsed_url.path.split('/')

        language_code = None
        country_code = None

        for component in path_components:
            if len(component) == 2:
                if not language_code:
                    language_code = component
                elif not country_code:
                    country_code = component
                else:
                    break
        if language_code:
            index_language = path_components.index(language_code)
            path_components = path_components[:index_language]
        if country_code:
            index_country = path_components.index(country_code)
            path_components = path_components[:index_country]

        base_url = f"{parsed_url.scheme}://{parsed_url.netloc}/"

        return base_url
    
    def clean_urls(self, urls):
        try:
            clean_words = ["youtube", "cloudflare", "linkedin", "facebook", "instagram", "twitter", "play.google.com"]
            final_urls = set()
            for url in urls:
                temp_url = copy(url).lower()
                flag = True
                for word in clean_words:
                    if word in temp_url:
                        flag = False
                        break
                if flag:
                    final_urls.add(url)
                else:
                    print("removed urls ---------->", temp_url)
            return list(final_urls)
        except Exception as e:
            print("\ninside exception part of clean_urls...")
            print("\nexception of clean_urls----->",e)
            return urls

    @staticmethod
    async def using_inner_links(url,domain_id,websiteId,ext):
        print("\nInside Inner Links-------------------")
        async with async_playwright() as p:
            print(f"Inside using_inner_links of {url}---------->",url)
            message="Please hold on a moment,we are fetching urls from your website..."
            message_data = {"websiteId":websiteId,"domainId":domain_id,"ext":ext,"progress":0,"message":message}
            message_data = json.dumps(message_data)
            print("\nredis message inside using_inner_links----->\n",message_data)
            rc.rpush("webscrap_res_1",message_data)
            browser = await p.chromium.launch()
            context = await browser.new_context(
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36"
            )
            page = await context.new_page()
            try:
                if url is None:
                    print(f"Inside try part of using_inner_links url {url}---------->",url)
                    await page.goto(url, timeout=60000)
                else:
                    print(f"Inside else part of using_inner_links url {url}---------->",url)
                    await page.goto(url, timeout=60000)
                
                inner_links = await page.query_selector_all('a[href^="https://"]')
                url_list = list(set([await link.get_attribute('href') for link in inner_links]))

                print(f"Length of all Inner URL's list {url}-----> ",len(url_list))
                return url_list
            except Exception as e:
                print(f"Inside exception part of using_inner_links {url} ----->")
                print(e)
                return []
            finally:
                if len(url_list) > 1100:
                    print(f"Length of inner_urls in finally part {url}----->",len(url_list))
                    return []
                await browser.close()

    def get_urls(self,domain_id,websiteId,ext,industry_type):
        print(f"\nInside get_url function of {self.base_url}-----------")
        print("BASE URL ---------->", self.base_url)
        list_of_inner_urls = asyncio.run(self.using_inner_links(self.base_url,domain_id,websiteId,ext))
        inner_urls = self.clean_urls(list_of_inner_urls)
        payload={
            'base_url': self.base_url
        }
        print("inside requests payload...")
        sitemap_urls = []
        try:
            message="Thanks for your patience,just a little more to go..."
            message_data = {"websiteId":websiteId,"domainId":domain_id,"ext":ext,"progress":0,"message":message}
            message_data = json.dumps(message_data)
            print("\nredis message inside sitemap_links----->\n",message_data)
            rc.rpush("webscrap_res_1",message_data)
            response=requests.post("http://10.150.3.150:4010/sitemap",json=payload)
            # response=requests.post("http://0.0.0.0:4015/sitemap",json=payload)
            list_of_url_in_sitemap = response.json()
            print(f"\nLength of sitemap url {self.base_url}----->",len(list_of_url_in_sitemap))
            sitemap_urls = self.clean_urls(list_of_url_in_sitemap)

        except requests.exceptions.Timeout as e:
            print('Timeout error...') # {"error": f"Request timed out: {str(e)}"}  # Handle timeout exception
            # raise e
        except requests.HTTPError as e:
            print('HTTP error...') # return {"error": f"HTTP error occurred: {str(e)}"}  # Handle HTTP errors
        except requests.RequestException as e:
            print('Requests Exception error...') # return {"error": f"An error occurred: {str(e)}"}

        print("\nAfter removing unwanted URL's...")
        print(f"Length of Inner URL {self.base_url} after clean_urls function called ---------->", len(inner_urls))
        print(f"Length of sitemap URL {self.base_url} after clean_urls function called ---------->", len(sitemap_urls))

        if industry_type == "Ecommerce" and len(sitemap_urls)==0:
            print(f"Industry type is Ecommerce for {self.base_url}-----")
            return None 
        if len(inner_urls) <=1100 and len(sitemap_urls) <= 1100:
            all_urls = inner_urls + sitemap_urls
            all_urls = list(set(all_urls))
            # print("\nAll url's ----->",all_urls)
            print(f"\nLength of all url's for {self.base_url}----->",len(all_urls))
            if len(all_urls) <= 1100:
                print(f"\nreturning all url's for {self.base_url}...")
                return all_urls
            elif len(inner_urls) >= len(sitemap_urls):
                print(f"\nreturning inner urls for {self.base_url}...")
                return inner_urls
            else:
                print(f"\nreturning sitemap urls for {self.base_url}...")
                return sitemap_urls
        else:
            print(f"\nreturning inner urls for {self.base_url}...")
            return inner_urls


    def get_docs(self,domain_id,websiteId,ext,industry_type):
        return self.get_urls(domain_id,websiteId,ext,industry_type)

def get_urls(base_url,domain_id,websiteId,ext,industry_type):
    a = URLIngestion(base_url=base_url)
    urls = a.get_docs(domain_id,websiteId,ext,industry_type)
    return urls

async def scrape_page(url: str, proxy: Optional[str] = None) -> str:
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        context = await browser.new_context(user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36')
        page = await context.new_page()
        await page.goto(url)
        await page.wait_for_timeout(60000)
        content = await page.content()
        soup = BeautifulSoup(content, 'html.parser')
        text_content = soup.get_text(separator='\n', strip=True)
        await browser.close()
        return text_content
    
# Function to scrape the page
async def scrape_web_page(url):
    try:
        text = await scrape_page(url)
        return text
    except:
        return ""

count = 0 
missed_count = 0

class scrappedCount:
    scraped_count = 0

async def task_coro(url):
    global count
    count += 1
    print(f'>task {url} executing , count {count}')
    # sleep for a

    doc = await scrape_web_page(url)
    # docs = [document.text for document in doc]
    if doc != "":
        print("URL : ",url,"-->",scrappedCount.scraped_count)
        # print("document------>",doc)
        scrappedCount.scraped_count+=1
    return doc

def generate_batch(lst, batch_size):
    """  Yields batch of specified size """
    for i in range(0, len(lst), batch_size):
        yield lst[i : i + batch_size]

# coroutine used for the entry point
async def crawl(batch):
    with Timer(text="\nTotal batch crawl time: {:.1f}"):
        print('===============batch starting===============')

        # create many tasks
        tasks = [task_coro(url=url) for url in batch]
        
        # run the tasks
        values = await asyncio.gather(*tasks)

        # report a message
        print('\n===============batch done===============')
        # print("values=========================================",values)
        return values

def start_crawling(b,domain_id,websiteId,ext, batch_size = 25,count = 0,batch_count = 0,user_url= ""):
    print(f"\nInside start_crawling for {user_url} ----->")
    docs = []
    gen = generate_batch(b, batch_size)
    print(f"\nLength of reordered url's for {user_url} ----->",len(b))
    progress = 85/(count/25)
    total_progress = progress
    gen = list(gen) 
    # print("\nTotal Batch ----->",gen)
    print(f"\nLength of total Batch of url {user_url} ----->",len(gen))
    
    no_of_batch = len(gen)

    if batch_count < len(gen) and batch_count != 0:
        no_of_batch = batch_count
        
    print(f"\nNumber of batch for url {user_url} ----->",no_of_batch)
    for i in range(no_of_batch):
        values = asyncio.run(crawl(batch=gen[i]))
        docs.extend(values)
        if i == len(gen)-1:
            progress_data = {"websiteId":websiteId,"domainId":domain_id,"ext":ext,"progress":85,"message":"Website Scraing is 85% completed. Machine Learning training is in progress. You will receive a notification upon completion. Please be patient."}
            progress_data = json.dumps(progress_data)
            print("\nredis rpush at 85% --->\n",progress_data)
            rc.rpush("webscrap_res_1",progress_data)      
            print("\nProgess:----------------------------------------------",85)
        else:
            progress_data = {"websiteId":websiteId,"domainId":domain_id,"ext":ext,"progress":total_progress,"message":""}
            progress_data = json.dumps(progress_data)
            rc.rpush("webscrap_res_1",progress_data)
            print("\nProgess---------------------------------------------",total_progress)
        total_progress+=progress
        print("\n===============================batch done=============================")
    print("\nType of docs=================================================== ",type(docs))
    
    return docs

class Data1(BaseModel):
    url_text: str
    domain_id:int
    websiteId:str
    ext:str
    industry_type:str

@app.post("/scrape")
def create_embeddings(data:Data1):
    try:
        batch_count = 44
        print("\n-----NEW URL GIVEN-----")
        print("\nUser Given Link ----->",data.url_text)
        print("Domain ID ----->",data.domain_id)
        print("Website ID ----->",data.websiteId)
        print("Extension ID ----->",data.ext)
        print("Industry Type ----->",data.industry_type)

        if data.url_text.startswith("www"):
            data.url_text = "https://"+data.url_text
        print("\nAfter appending https ---------->",data.url_text)
        urls = get_urls(data.url_text,domain_id=data.domain_id,websiteId=data.websiteId,ext=data.ext,industry_type=data.industry_type)
        # print("\nFinal URL's---------->",urls)

        if urls == None:
            return {"domainId":data.domain_id,"wesiteId":data.websiteId,"message":"Unable to scrape the site as it exceeds the URL limit. So, please upload the knowledge base in CSV or PDF format."}
        print(f"\nLength of final URL's for {data.url_text}----->",len(urls))

        if len(urls)==0:
            print()
            return {"domainId":data.domain_id,"wesiteId":data.websiteId,"message": "Unable to scrape the site as it exceeds the URL limit. So, please upload the knowledge base in CSV or PDF format."} 
        
        url_length = len(list(urls))
        print(f"\nURL's count for url {data.url_text}-----> {url_length}")

# -----------------------------------------------------------------------------------------------------
        
        imp_page = ["faq","FAQ","FAQs","support","Support","help","Help","HELP","products","product","pricing","price","cost","aboutus","about-us","Aboutus","solution","solutions","plans","plan","business","Business","enterprise","Enterprise","contact","Contact","conditions","Conditions","condition","menu","Menu"]

        present = False
        for i in imp_page:
            for j in urls:
                if i in j:
                    present = True
                    break
                elif len(urls)<20 and (i not in j):
                    present = True
                    break
            if present == True:
                break

        if present == True:
            a=[]
            b=[]
            for link in urls:
                contains_important_word = False
                for word in imp_page:
                    if word in link:
                        contains_important_word = True
                        break

                if contains_important_word:
                    b.append(link)
                else:
                    a.append(link)
            b.extend(a)

            try:
                docs = start_crawling(b,domain_id=data.domain_id,websiteId=data.websiteId,ext = data.ext,batch_size=25,count=len(b),batch_count = batch_count,user_url = data.url_text)
                scrappedCount.scraped_count = 0
                # service_context = ServiceContext.from_defaults(embed_model=embed_model,llm = None,chunk_size=300, chunk_overlap=50)
                print(f"\nLength of docs for url {data.url_text} ----->",len(docs))
                print(f"\ninside try part of embedding the url --- {data.url_text} ---")
                text_docs = "".join(docs)

                segmented_text = CustomEmbeddingModel.segment_text(text_docs, chunk_size=50)
                # List of models
                model_names = [
                    'sentence-transformers/all-mpnet-base-v2',
                    "BAAI/bge-large-en-v1.5",
                    'sentence-transformers/all-MiniLM-L6-v2',
                    "thenlper/gte-base",
                    "llmrails/ember-v1"  # Add additional model paths if needed
                ]

                # Initialize models and store in a list
                models = [CustomEmbeddingModel(model_name=name) for name in model_names]

                # Encode sentences for each model
                no = 1
                for model, model_name in zip(models, model_names):
                    embeddings = model.encode_text(segmented_text)
                    database_path = f"/root/web_crawl_live/llama_index_webcrawl/embedded_data_v2/{data.domain_id}/{data.websiteId}" + str(no)
                    # database_path = f"embedded_data_v2/{data.domain_id}/{data.websiteId}" + str(no)
                    model.save_vectors_to_chromadb(embeddings, segmented_text, database_path)
                    no+=1

                torch.cuda.empty_cache()
                gc.collect()
                print(f"\nEmbedded files saved path ---> /root/web_crawl_live/llama_index_webcrawl/embedded_data_v2/{data.domain_id}/{data.websiteId}folder")
                current_datetime = datetime.now()
                print(f"current time website_id : {data.websiteId} domain : {data.domain_id}---->",current_datetime)
                print("\nProgress-------------------------------",100)
                print()
                progress_data = {"websiteId":data.websiteId,"domainId":data.domain_id,"ext":data.ext,"progress":100}
                progress_data = json.dumps(progress_data)
                print()
                rc.rpush("webscrap_res_1",progress_data)
                print()
                return {"domainId":data.domain_id,"wesiteId":data.websiteId,"message": "success"}
            except Exception as e:
                print("\ninside exception part of embedding...")
                print(f"\nexception for the url --- {data.url_text} ---",e)
                return {"domainId":data.domain_id,"wesiteId":data.websiteId,"message": "Apologies for the Machine Learning Trainig Error. Kindly upload the knowledge base in CSV or PDF format for processing."}
        else:
            return {"domainId":data.domain_id,"wesiteId":data.websiteId,"message": "Sorry, the website cannot be reached. Please upload the knowledge base in the format of CSV or PDF."}

    except Exception as e:
        print(e)
        current_datetime = datetime.now()
        print()
        print(f"current time website_id : {data.websiteId} domain : {data.domain_id}---->",current_datetime)
        print()
        return {"domainId":data.domain_id,"wesiteId":data.websiteId,"message": "Sorry, the website cannot be reached. Please upload the knowledge base in the format of CSV or PDF."}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=4005)

