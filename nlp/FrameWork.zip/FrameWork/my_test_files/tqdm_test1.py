# import tqdm
# from tqdm import tqdm
# from time import sleep
# for i in tqdm(range(10000),desc="scrapping"):
#     sleep(0.001)

# from tqdm.auto import tqdm, trange
# from time import sleep

# bar = trange(10)
# for i in bar:
#     # Print using tqdm class method .write()
#     sleep(0.1)
#     if not (i % 3):
#         tqdm.write("Done task %i" % i)
#     # Can also use bar.write()


from tqdm import tqdm
import time

# List of 45 links
links = [f"https://example.com/page{i}" for i in range(1, 46)]

# Calculate the total number of iterations
total_iterations = len(links)

# Initialize tqdm progress bar
with tqdm(total=total_iterations, desc="Processing",colour="green") as pbar:
    for link in links:
        # Simulating some operation (e.g., scraping, processing)
        time.sleep(0.5)  # Replace with your actual operation

        # Update progress bar
        pbar.update(1)

# Manually update the progress bar to 100% at the end of the loop
pbar.update(total_iterations - pbar.n)

print("Processing complete.")
