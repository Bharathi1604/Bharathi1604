import pdfplumber

pdf = pdfplumber.open('SIM Only Deals _ No Contract _ Lyca Mobile_Best deals.pdf')

print(pdf.pages[0].extract_text())