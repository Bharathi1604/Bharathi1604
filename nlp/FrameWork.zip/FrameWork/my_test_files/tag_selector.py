from playwright.sync_api import sync_playwright
import re
def extract_text(url, tag_selector):
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        page.goto(url)
        # Wait for the selector to be present on the page
        page.wait_for_selector(tag_selector)
        # Extract text from the specified tag
        text = page.text_content(tag_selector)
        browser.close()
        text = remove_html_tags(text)
        with open("test_3.json","w") as f:
            f.write(text)
    return text


def remove_html_tags(text):
    clean = re.compile('<.*?>')
    return re.sub(clean, '', text)

# Example usage:
url = "https://www.lycamobile.co.uk/en/help/faq/"
tag_selector = "a"  # Replace with your desired tag selector
result = extract_text(url, tag_selector)
print(f"Text from {tag_selector}: {result}")
