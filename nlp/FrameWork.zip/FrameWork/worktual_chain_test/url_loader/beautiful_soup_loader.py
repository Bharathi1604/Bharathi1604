import requests
from bs4 import BeautifulSoup
from typing import Union, List
from tqdm import tqdm  # If using Jupyter Notebook or console, to display progress bar
from abc import ABC,abstractmethod

class UrlLoader(ABC):
    @abstractmethod
    def load():
        pass
    
    @abstractmethod
    def scrape():
        pass

    @abstractmethod
    def getText():
        pass

class BeautifulsoupLoader(UrlLoader):

    def __init__(self, url: Union[str, List[str]], tag_selector: str = None, show_progress: bool = False):
        super().__init__()
        self.url = url
        self.tag_selector = tag_selector
        self.show_progress = show_progress
        self.scrapped_text = []

    def load(self):
        if isinstance(self.url, str):
            return self.scrape([self.url])
        elif isinstance(self.url, list) and all(isinstance(item, str) for item in self.url):
            return self.scrape(self.url)
        else:
            return "URLs are empty or not properly formatted."

    def getText(self, url_link):
        response = requests.get(url_link)
        soup = BeautifulSoup(response.content, 'html.parser')

        if self.tag_selector:
            selected_tags = soup.select(self.tag_selector)
            text_content = [tag.get_text(strip=True) for tag in selected_tags]
        else:
            text_content = soup.get_text(strip=True)

        return text_content

    def scrape(self, urls):
        if self.show_progress:
            urls = tqdm(urls, desc="Scraping...")

        for url in urls:
            try:
                self.scrapped_text.append(self.getText(url))
            except requests.RequestException as e:
                print(f"Error accessing {url}: {e}")

        return self.scrapped_text


loader = BeautifulsoupLoader(url="https://www.delightmobile.co.uk/",show_progress=True)

documents = loader.load()
print(documents)
