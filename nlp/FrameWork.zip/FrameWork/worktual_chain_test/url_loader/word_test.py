s = "hi this is bharathi. my intrest is to become data scientist,and to become skilled. thankyou for this wonderfull life"

def word_split(sentence,chunk_size = 100,overlap = 20):
    sentence = sentence.split()
    i = 0
    splited_text = []
    temp_text = ""
    last_text = ""
    while i < len(sentence):
        temp_text += sentence[i]+" "
        # print(temp_text)
        if temp_text.count(" ") > chunk_size:
            splited_text.append(temp_text)
            temp_last_text = " ".join(sentence[i-overlap :i+1])
            if "." in temp_last_text:
                last_text = temp_last_text.split(".")[-1]
                print(last_text)
            temp_text = last_text+" "
            last_text = ""
        i+=1
    splited_text.append(temp_text)

    return splited_text

print(word_split(s,7,4))