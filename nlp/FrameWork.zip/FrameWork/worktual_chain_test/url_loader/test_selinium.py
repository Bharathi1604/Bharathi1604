from selenium import webdriver
import time

# Set the path to your webdriver (e.g., chromedriver.exe)
driver_path = '/path/to/your/webdriver'

# Initialize the browser (e.g., Chrome)
browser = webdriver.Chrome(executable_path=driver_path)

# URL of the website to scrape
url = 'https://example.com'

# Open the website
browser.get(url)

# Wait for 10 seconds to allow the page to load completely
time.sleep(10)

# Get the HTML content of the page
html_content = browser.page_source

# Print or process the HTML content as needed
print(html_content)

# Close the browser
browser.quit()
