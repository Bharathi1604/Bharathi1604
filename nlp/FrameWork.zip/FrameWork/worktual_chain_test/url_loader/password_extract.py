import re

def extract_passwords(user_query):
    passwords = []
    pattern = r'(?=.*[A-Z])(?=.*\d).{8,}'
    for text in user_query.split():
        password = re.findall(pattern, text)
        if password:
            passwords.extend(password)
    return passwords

print(extract_passwords("hi m25dgghgy password is Akjeddgn1 Bharathi1"))