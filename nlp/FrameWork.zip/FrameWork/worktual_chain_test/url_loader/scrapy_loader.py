from typing import Union, List
from abc import ABC, abstractmethod
import scrapy
from scrapy.crawler import CrawlerProcess

class UrlLoader(ABC):
    @abstractmethod
    def load(self):
        pass

class ScrapyLoader(UrlLoader, scrapy.Spider):
    name = 'scrapy_loader'

    def __init__(self, urls: Union[str, List[str]], tag_selector: str = None):
        super().__init__()
        self.start_urls = urls if isinstance(urls, list) else [urls]
        self.tag_selector = tag_selector
        self.scrapped_text = []

    def parse(self, response):
        if self.tag_selector:
            selected_tags = response.css(self.tag_selector).getall()
            text_content = [tag.strip() for tag in selected_tags]
        else:
            text_content = response.css('body::text').getall()

        self.scrapped_text.extend(text_content)

    def load(self):
        process = CrawlerProcess()
        process.crawl(self.__class__, urls=self.start_urls, tag_selector=self.tag_selector)
        process.start()

        return self.scrapped_text

# Example usage:
urls_to_scrape = ['https://www.delightmobile.co.uk/']
loader = ScrapyLoader(urls=urls_to_scrape, tag_selector='p')  # Change 'p' to your desired CSS selector
documents = loader.load()

print(documents)
