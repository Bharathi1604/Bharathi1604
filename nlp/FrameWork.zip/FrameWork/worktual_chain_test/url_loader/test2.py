from pathlib import Path
import os
path: str = os.getcwd()
osDir = Path(path)
print(path)
print(str(osDir.absolute()))