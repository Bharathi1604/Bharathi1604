from tqdm import tqdm
from pytube import YouTube
from typing import Union,List
from transformers import pipeline
import os
from pathlib import Path


class YouTubeLoader():

    def __init__(self,url:Union[str, List[str]],show_progress:bool = False,store_audio = False,destination:str = None,device = -1,model = 'openai/whisper-base'):
        self.url = url
        self.show_progress = show_progress
        if destination == None:
            self.destination = os.getcwd()
        else:
            self.destination = destination
        self.store_audio = store_audio
        self.transcribed_texts = []
        self.pipeline = pipeline('automatic-speech-recognition', model = model,device = device)

    def get_audio(self,url):
        video = YouTube(url)
        audio = video.streams.filter(only_audio=True).first()
        output = audio.download(output_path = self.destination)
        print("=============",Path(output))
        file_name = video.title
        new_file = file_name + '.mp3'
        new_file = os.path.join(self.destination,new_file)
        os.rename(Path(output), new_file)
        return new_file
    
    def transcribe(self,file_name):
       transcribed_text = self.pipeline(file_name)["text"]
       return transcribed_text
    
    def get_transcription(self,urls):
        if self.show_progress == True:
            urls = tqdm(urls)
        else:
            urls = urls

        for url in urls:
            if self.show_progress == True:
                urls.set_description(f"{url} is transcribing")
            audio_file = self.get_audio(url)
            self.transcribed_texts.append(self.transcribe(audio_file))
            if not self.store_audio:
                os.remove(audio_file)
        return self.transcribed_texts

    def load(self):
        if isinstance(self.url,str):
            return self.get_transcription([self.url])
        elif isinstance(self.url,list) and all(isinstance(item, str) for item in self.url):
            return self.get_transcription(self.url)
        else:
            return "url is empty"
        

loader = YouTubeLoader(["https://www.youtube.com/watch?v=TtKF996oEl8"],show_progress=True,store_audio=True)

text = loader.load()
for i in text:
    print(i)