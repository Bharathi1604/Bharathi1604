import requests 

data = requests.get("https://www.delightmobile.co.uk/")

print(data.content)