import scrapy
from scrapy.crawler import CrawlerProcess
from unstructured.partition.html import partition_html


class TextSpider(scrapy.Spider):
    name = 'text_spider'
    start_urls = ["https://www.lycamobile.co.uk/en/"]  # Replace with the URL you want to scrape

    def parse(self, response):
        text = ' '.join(response.xpath('//text()').extract())
        elements = partition_html(text=text)
        text_content = " ".join([str(el) for el in elements])
        yield {
            'text': text_content
        }

def run_spider():
    process = CrawlerProcess()
    process.crawl(TextSpider)
    process.start()

if __name__ == "__main__":
    run_spider()