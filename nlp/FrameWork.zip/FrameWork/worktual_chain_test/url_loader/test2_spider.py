# from playwright.async_api import async_playwright
# import asyncio
# from bs4 import BeautifulSoup
# from typing import Optional, List

# async def scrape_page(url: str, proxy: Optional[str] = None) -> str:
#     async with async_playwright() as p:
#         browser = await p.chromium.launch()
#         context = await browser.new_context(user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36')
#         page = await context.new_page()
#         await page.goto(url)
#         await page.wait_for_timeout(10000)
#         content = await page.content()
#         print(content)
#         soup = BeautifulSoup(content, 'html.parser')
#         text_content = soup.get_text(separator='\n', strip=True)
#         await browser.close()
#         with open("test2.txt","w") as f:
#              f.write(text_content)
#         return text_content
    
# asyncio.run(scrape_page("https://www.lycamobile.co.uk/en/"))


import scrapy
from scrapy.crawler import CrawlerProcess
from bs4 import BeautifulSoup

class MySpider(scrapy.Spider):
    name = 'myspider'
    start_urls = ['https://www.lycamobile.co.uk/en/']
    text = ""
    download_delay=5

    def parse(self, response):
        # Process the HTML content here
        # You can access the HTML content using response.body or response.text
        # For example, to print the HTML content:
        response = scrapy.Request(
                response.url,
                dont_filter=True
            )
        MySpider.text = response.text

# Run the spider within the Python script
if __name__ == "__main__":
    process = CrawlerProcess(settings={
        'USER_AGENT': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'LOG_LEVEL': 'ERROR',
        'DOWNLOAD_DELAY': 3
        
    })

    process.crawl(MySpider)
    process.start()
    print(MySpider.text)
    soup = BeautifulSoup(MySpider.text, 'html.parser')
    text_content = soup.get_text(separator='\n', strip=True)
    print(text_content)
