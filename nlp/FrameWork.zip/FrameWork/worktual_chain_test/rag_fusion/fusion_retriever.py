import os
from sentence_transformers import SentenceTransformer
import chromadb
from semantic_text_splitter import HuggingFaceTextSplitter
from tokenizers import Tokenizer

class EmbeddStoreChromaST:
    def __init__(self, model_name):
        self.model = SentenceTransformer(model_name,device = "cpu")

    @classmethod
    def save_vectors_to_chromadb(cls, embeddings, documents, db_path):
        client = chromadb.PersistentClient(path=os.path.abspath(db_path))
        try:
            client.delete_collection("testdb10")
        except:
            pass
        collection = client.create_collection("testdb10")
    
        collection.add(embeddings=embeddings, documents=documents, ids=[f"id{i}" for i in range(1, len(embeddings) + 1)])
        print(f"ChromaDB saved successfully to {db_path}")

    def encode_text(self, text):
        embeddings = self.model.encode(text, convert_to_tensor=True)
        return embeddings.tolist()

    def segment_text(file_contents, chunk_size):
        tokenizer = Tokenizer.from_pretrained("bert-base-uncased")
        splitter = HuggingFaceTextSplitter(tokenizer, trim_chunks=False)

        sentences = splitter.chunks(file_contents, chunk_size)

        result_chunks = []
        current_chunk = ""
        for i in range(len(sentences)):
            current_chunk += f" {sentences[i]}"
            if current_chunk.count(" ") >= 256:
                result_chunks.append(current_chunk)
                current_chunk = f"{sentences[i-2]} {sentences[i-1]} {sentences[i]}"
        return result_chunks