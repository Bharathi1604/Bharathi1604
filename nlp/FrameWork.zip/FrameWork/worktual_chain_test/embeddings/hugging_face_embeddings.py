import numpy as np
from transformers import AutoModel, AutoTokenizer
import asyncio
from abc import ABC,abstractmethod
import torch

class BaseEmbedding(ABC):
    def __init__(self, device='cpu'):
        self.device = torch.device(device)
        
    @abstractmethod
    def generate_embeddings(self, text):
        pass
    
    @abstractmethod
    async def generate_embeddings_async(self, text):
        pass

class HuggingFaceEmbedding(BaseEmbedding):
    def __init__(self, model_name: str = "bert-base-uncased"):
        super().__init__()
        self.model = AutoModel.from_pretrained(model_name)
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)

    def generate_embeddings(self, text):
        tokens = self.tokenizer(text, return_tensors='pt', truncation=True, padding=True)
        outputs = self.model(**tokens)
        embeddings = np.mean(outputs.last_hidden_state.numpy(), axis=1).squeeze()
        return embeddings

    async def generate_embeddings_async(self, text):
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.generate_embeddings, text)

embedder = HuggingFaceEmbedding(model_name="sentence-transformers/all-MiniLM-L6-v2")

emdeddings = embedder.generate_embeddings("hi")