import torch
import asyncio
from sentence_transformers import SentenceTransformer
from abc import ABC,abstractclassmethod

class BaseEmbedding(ABC):

    @abstractclassmethod
    def generate_embeddings(self, text):
        pass
    
    @abstractclassmethod
    async def generate_embeddings_async(self, text):
        pass


class SentenceTransformersEmbedding(BaseEmbedding):
    def __init__(self, model_name:str = "sentence-transformers/all-MiniLM-L6-v2", device:str = 'cpu',show_progress:str = False):
        super().__init__()
        self.show_progress = show_progress
        self.model = SentenceTransformer(model_name,device=device)

    def generate_embeddings(self, text):
        embeddings = self.model.encode(text,show_progress_bar=self.show_progress)
        return embeddings  # Return embeddings as NumPy array

    async def generate_embeddings_async(self, text):
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.generate_embeddings, text)
    

# Example usage:
if __name__ == "__main__":
    model_name = "paraphrase-MiniLM-L6-v2"  # Replace with the desired model name
    sentence_transformer = SentenceTransformersEmbedding("BAAI/bge-small-en")
    
    # text = ["Example text for Sentence Transformers embedding.", "Another sentence."]
    text = """What do you mean by "flip" term?
Can you explain the meaning behind "call flip"?
What does "flip" refer to in this context?
Can you provide an alternative term for "call flip"?
How can you describe "call flip" in different words?
What could be a similar concept or action to "call flip"?
What might be another name for "call flip"?
Can you give an example of using "call flip"?
In what situation would someone use "call flip"?
What is the purpose of "call flip"?
What could be a related term to "call flip"?
How can you define "call flip" in simple terms?
Can you offer a brief explanation of "call flip"?
What might be a close synonym for "call flip"?
What could be a possible alternative term for "call flip"?
How can you rephrase "call flip" into simpler words?
What might be a similar expression to "call flip"?
Can you provide a different way to express "call flip"?
What could be a similar term to "call flip"?
How can you reword "call flip" to make it more understandable?
What might be a comparable phrase to "call flip"?
Can you give an alternate description for "call flip"?
What could be a similar term to "call flip"?
How can you simplify the meaning of "call flip"?
What might be a similar expression to "call flip"?
Can you offer a different definition for "call flip"?
What could be a similar term to "call flip"?
How can you rephrase "call flip" to make it clearer?
What might be a comparable term to "call flip"?
Can you provide an alternative explanation for "call flip"?
What could be a similar expression to "call flip"?
Can you give an alternative definition for "call flip"?
What might be a similar term to "call flip"?
How can you reword "call flip" to make it easier to understand?
What could be a comparable term to "call flip"?
Can you offer a different description for "call flip"?
What might be a similar expression to "call flip"?
Can you provide an alternative definition for "call flip"?
What could be a similar term to "call flip"?
How can you rephrase "call flip" to make it more straightforward?
What might be a comparable term to "call flip"?
Can you offer a different explanation for "call flip"?
What could be a similar term to "call flip"?
How can you reword "call flip" to make it less complicated?
What might be a comparable term to "call flip"?
Can you provide an alternative definition for "call flip"?
What could be a similar term to "call flip"?
How can you rephrase "call flip" to make it more accessible?
What might be a comparable term to "call flip"?
Can you offer a different explanation for "call flip"?""".split("?")
    sentence_embeddings = sentence_transformer.generate_embeddings(text)
    print(sentence_embeddings)