from transformers import AutoTokenizer, AutoModel
import numpy as np

class HuggingFaceEmbeddings:
    def __init__(self, model_name):
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModel.from_pretrained(model_name)

    def generate_embeddings(self, text):
        inputs = self.tokenizer(text, return_tensors="pt")
        outputs = self.model(**inputs)
        hidden_states = outputs.last_hidden_state.detach().numpy()
        embeddings = np.mean(hidden_states, axis=1).squeeze()
        return embeddings

# Example usage
model_name = "BAAI/bge-small-en-v1.5"  # You can change this to your desired pre-trained model
embedder = HuggingFaceEmbeddings(model_name)

text_to_embed = "Hello, how are you?"
embeddings = embedder.generate_embeddings(text_to_embed)
print(embeddings)
