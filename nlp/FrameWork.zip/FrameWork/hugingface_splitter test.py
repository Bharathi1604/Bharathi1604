from sentence_splitter import SentenceSplitter, split_text_into_sentences


text = """This was followed by the Model S sedan in 2012, the Model X SUV in 2015, the Model 3 sedan in 2017, the Model Y crossover in 2020, the Tesla Semi truck in 2022 and the Cybertruck light-duty pickup truck in 2023.[7] The Model 3 is the all-time bestselling plug-in electric car worldwide, and in June 2021 became the first electric car to sell 1 million units globally.[8] Tesla's 2022 deliveries were around 1.31 million vehicles, a 40% increase over the previous year,[9][10] and cumulative sales totaled 4 million cars as of April 2023.[11] In October 2021, Tesla's market capitalization temporarily reached $1 trillion, the sixth company to do so in U.S. history.Tesla has been the subject of lawsuits, government scrutiny, and journalistic criticism, stemming from allegations of whistleblower retaliation, worker rights violations, product defects, and Musk's many controversial statements. /n/n"""

splitter = SentenceSplitter(language='en')
sentences = splitter.split(text=text)

print(len(sentences))

for i in sentences:
    print(i,"/n/n")


# print(split_text_into_sentences(
#     text=text,
#     language='en'
# ))
