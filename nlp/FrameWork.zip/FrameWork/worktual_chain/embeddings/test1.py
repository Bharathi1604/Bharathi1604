from duckduckgo_search import DDGS

with DDGS() as ddgs:
    results = [r for r in ddgs.text("who was the prime minister of india in 2003", max_results=5)]


for i in results:
    print(i,"\n")