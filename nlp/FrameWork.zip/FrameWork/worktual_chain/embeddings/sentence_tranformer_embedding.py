import torch
import asyncio
from sentence_transformers import SentenceTransformer

class BaseEmbedding:
    def __init__(self, device='cpu'):
        self.device = torch.device(device)

    def generate_embeddings(self, text):
        raise NotImplementedError("generate_embeddings method must be implemented in the subclass")

    async def generate_embeddings_async(self, text):
        raise NotImplementedError("generate_embeddings_async method must be implemented in the subclass")



class SentenceTransformersEmbedding(BaseEmbedding):
    def __init__(self, model_name:str = "sentence-transformers/all-MiniLM-L6-v2", device:str = 'cpu'):
        super().__init__(device=device)
        self.model = SentenceTransformer(model_name)

    def generate_embeddings(self, text):
        embeddings = self.model.encode(text)
        return embeddings  # Return embeddings as NumPy array

    async def generate_embeddings_async(self, text):
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.generate_embeddings, text)


# Example usage:
if __name__ == "__main__":
    model_name = "paraphrase-MiniLM-L6-v2"  # Replace with the desired model name
    sentence_transformer = SentenceTransformersEmbedding("BAAI/bge-small-en")
    
    text = ["Example text for Sentence Transformers embedding.", "Another sentence."]
    sentence_embeddings = sentence_transformer.generate_embeddings(text)
    print(sentence_embeddings)