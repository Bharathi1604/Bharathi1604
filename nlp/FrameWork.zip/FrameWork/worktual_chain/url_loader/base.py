from abc import ABC,abstractmethod

class UrlLoader(ABC):
    @abstractmethod
    def load():
        pass
    
    @abstractmethod
    def scrape():
        pass

    @abstractmethod
    def getText():
        pass