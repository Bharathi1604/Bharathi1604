from playwright.sync_api import sync_playwright,TimeoutError as PlaywrightTimeoutError
from unstructured.partition.html import partition_html
from typing import Union, List
from tqdm import tqdm
from url_loader.base import UrlLoader

class PlayWrightLoader(UrlLoader):

    def __init__(self,url:Union[str, List[str]], tag_selector:str = None, show_progress:bool = False,timeout:int = 30000):
        super().__init__()
        self.url = url
        self.tag_selector = tag_selector
        self.show_progress = show_progress
        self.timeout = timeout
        self.scrapped_text = []

    def load(self):
        if isinstance(self.url,str):
            return self.scrape([self.url])
        elif isinstance(self.url,list) and all(isinstance(item, str) for item in self.url):
            return self.scrape(self.url)
        else:
            return "url is empty"

    def getText(self,url_link):
        with sync_playwright() as p:
            browser = p.chromium.launch()
            context = browser.new_context(user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36')
            page = context.new_page()
            page.goto(url_link,timeout = self.timeout)
            page.wait_for_timeout(5000)
            
            # Wait for the selector to be present on the page
            if self.tag_selector != None:
                tag_selector = self.tag_selector
                # Specify the CSS selector of the tags you want to extract text from
                selected_tags = page.query_selector_all(tag_selector)
                text_content = [tag.text_content() for tag in selected_tags]

            else:
                 # Extract text from the specified tag
                content = page.content()
                # unstructured_partition
                elements = partition_html(text=content)
                text_content = " ".join([str(el) for el in elements])

            browser.close()
        return text_content
    
    def scrape(self,urls):
        if self.show_progress:
            urls = tqdm(urls,desc="Scraping...")

        for url in urls:
            try:
                self.scrapped_text.append(self.getText(url))
            except PlaywrightTimeoutError as e:
                print(url,f" Timeout error: exceeds time limit {self.timeout} seconds")

        return self.scrapped_text

