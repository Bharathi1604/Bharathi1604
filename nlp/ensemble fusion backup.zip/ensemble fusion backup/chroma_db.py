import os
from sentence_transformer_embedding import SentenceTransformersEmbedding
import chromadb
from semantic_text_splitter import HuggingFaceTextSplitter
from tokenizers import Tokenizer
from chromadb import Documents, EmbeddingFunction, Embeddings

class ChromaDB:
    def __init__(self,embedding_model = None,device:str = "cpu"):
        if embedding_model == None:
            self.embedder = SentenceTransformersEmbedding(device = device)
        else:
            self.embedder = embedding_model

    def save(self,documents, db_path,collection_name:str = "quickstart" ):
        client = chromadb.PersistentClient(path=os.path.abspath(db_path))
        collection = client.create_collection(collection_name,metadata={"hnsw:space": "cosine"})
        embeddings = self._get_document_embeddings(documents)
        collection.add(embeddings=embeddings, documents=documents, ids=[f"id{i}" for i in range(1, len(embeddings) + 1)])
        print(f"ChromaDB saved successfully to {db_path}")
        
    def _get_document_embeddings(self,text):
        return self.embedder.embed(text)
        
    def retrieve(self,user_input,db_path,collection_name = "quickstart",top_k = 1):
        client = chromadb.PersistentClient(path=os.path.abspath(db_path))
        collection = client.get_collection(collection_name)
        # return collection  
        results = collection.query(
        query_embeddings = [self._get_document_embeddings(user_input)],
        n_results=top_k,
        )
        scores = results["distances"][0]
        documents = results["documents"][0]
        ids = results["ids"][0]
        retrieved_data = [[document,score,id] for document,score,id in zip(documents, scores,ids)]
        return retrieved_data

ChromaDB()