import torch
import asyncio
from sentence_transformers import SentenceTransformer
from abc import ABC,abstractclassmethod

class BaseEmbedding(ABC):

    @abstractclassmethod
    def _generate_embeddings(self, text):
        pass
    @abstractclassmethod
    def embed(self, text):
        pass


class SentenceTransformersEmbedding(BaseEmbedding):
    def __init__(self, model_name:str = "sentence-transformers/all-MiniLM-L6-v2", device:str = 'cpu',show_progress:str = False):
        super().__init__()
        self.show_progress = show_progress
        self.model_name = model_name
        self.device = device
        self.model = SentenceTransformer(self.model_name,device=self.device)

    def _generate_embeddings(self, text):
        embeddings = self.model.encode(text,show_progress_bar=self.show_progress).tolist()
        return embeddings
        
    def embed(self, text):
        return self._generate_embeddings(text)