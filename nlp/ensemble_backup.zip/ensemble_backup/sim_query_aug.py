from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
#from variations_five import RequestHandler

class SentenceEmbedder:
    def __init__(self, model_path):
        self.model = SentenceTransformer(model_path)

    def generate_embeddings(self, sentences):
        embeddings = self.model.encode(sentences)
        return embeddings

    def find_most_similar_sentence(self, query, sentences, sentence_embeddings, top_n=1):
        query_embedding = self.model.encode([query])[0]
        similarities = cosine_similarity([query_embedding], sentence_embeddings)[0]
        top_similar_indices = similarities.argsort()[-top_n:][::-1]
        top_similar_sentences = [sentences[idx] for idx in top_similar_indices]
        return top_similar_sentences

# Example usage:
if __name__ == "__main__":
    # Example list of sentences
    telecommunication_sentences = [
    "Telecommunication serves as a cornerstone for global connectivity, enabling communication between individuals worldwide.",
    "The advent of 5G technology promises faster speeds and lower latency, revolutionizing how we communicate and access information.",
    "Fiber-optic cables, with their high-speed data transmission capabilities, form the backbone of modern telecommunication networks.",
    "Satellite communication plays a pivotal role in delivering broadcasting, navigation, and internet services on a global scale.",
    "The Internet of Things (IoT) relies on telecommunication infrastructure to interconnect and enable communication between devices.",
    "Secure telecommunication protocols and encryption methods ensure data privacy and confidentiality during transmission.",
    "Telecommunication regulations and standards govern network operations to ensure fair competition and consumer protection.",
    "Telecommunication companies invest in research and development to innovate and meet the evolving needs of users.",
    "Emerging technologies, such as artificial intelligence and blockchain, are integrated into telecommunication systems for enhanced functionality.",
    "Continuous advancements in telecommunication contribute to the evolution of smart cities and interconnected digital ecosystems."
]

    # Path to the pre-trained model
    model_path = 'paraphrase-MiniLM-L6-v2'  # Replace this with your desired model path

    # Queries
    # queries = [
    #     "How does telecommunication enable global connectivity?",
    #     "What impact does 5G technology bring to communication?",
    #     # Add your remaining queries here...
    # ]

    queries = [
    "What role does telecommunication play in facilitating worldwide connections?",
    "In what ways does telecommunication contribute to establishing global connectivity?",
    "How is global connectivity achieved through telecommunication?",
    "What are the mechanisms by which telecommunication fosters global connections?",
    "How does telecommunication support the establishment of connections on a global scale?"
]


    # Create an instance of SentenceEmbedder class
    sentence_embedder = SentenceEmbedder(model_path)

    # Generate embeddings for the list of sentences
    sentence_embeddings = sentence_embedder.generate_embeddings(telecommunication_sentences)

    # Process queries and find most similar sentences
    uniq_retrieval = []
    for query in queries:
        most_similar_sentences = sentence_embedder.find_most_similar_sentence(query, telecommunication_sentences, sentence_embeddings)
        #print(f"Query: {query}")
        #print(f"Most similar sentence(s): {most_similar_sentences}\n")
        uniq_retrieval.extend(most_similar_sentences)
    print(uniq_retrieval)
    
    unique_sentences = list(set(uniq_retrieval))

    print(unique_sentences)

