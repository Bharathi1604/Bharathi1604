from playwright.async_api import async_playwright
from unstructured.partition.html import partition_html
import chromadb
import asyncio

from codetiming import Timer
import logging
from bs4 import BeautifulSoup
import requests
import uvicorn
from pydantic import BaseModel
from fastapi import FastAPI
from urllib.parse import urlparse,urljoin

from llama_index import VectorStoreIndex,ServiceContext
from llama_index.vector_stores import ChromaVectorStore
from llama_index.storage.storage_context import StorageContext
from llama_index.embeddings import HuggingFaceEmbedding
import chromadb
from llama_index.node_parser import SimpleNodeParser
import llama_index
import unicodedata
from typing import Optional
import asyncio
from fastapi.middleware.cors import CORSMiddleware
from time import sleep

# redis_cli = Redis(host="localhost",port=6379)

logger = logging.getLogger(__name__)
TIME_OUT = 60000


app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Set the allowed origins. You can customize this based on your needs.
    allow_credentials=True,  # Set to True if your API allows credentials (e.g., cookies, authentication headers)
    allow_methods=["*"],  # Set the allowed HTTP methods. You can customize this based on your needs.
    allow_headers=["*"],  # Set the allowed HTTP headers. You can customize this based on your needs.
)


chroma_client = chromadb.EphemeralClient()
# define embedding function



class URLIngestion():

    def __init__(self,base_url):
        self.base_url = base_url
        #self.sitemap_xml = self.base_url + "/sitemap.xml"
        site_map_url = remove_language_code(base_url)
        self.sitemap_xml = urljoin(site_map_url, "sitemap.xml")
        
    
    async def using_inner_links(self,url = None):
        print("IAM HERE===================================")
        async with async_playwright() as p:
            print("Now I am Here======================================")
            browser = await p.chromium.launch()
            page = await browser.new_page()
            if url == None:
                await page.goto(self.base_url)
                print(self.base_url)
            else:
                await page.goto(url)
                print(url)
            # Use Playwright to select and extract the href links in Python
            anchors = await page.query_selector_all('a')
            base_url = page.url

            links = []

            for anchor in anchors:
                href = await anchor.get_attribute('href')
                if href and (href.startswith('https://') or href.startswith('/')):
                    full_url = urljoin(base_url, href)
                    links.append(full_url)

            await browser.close()
            links = list(set(links))
            # Print the extracted links line by line
            return links

        
    def using_sitemap(self,url = None):
        if  url == None:
            r = requests.get(self.sitemap_xml)
            print(self.sitemap_xml)
        else:
            r = requests.get(url)
            print(url)
        soup = BeautifulSoup(r.content, features='xml')
        urls_raw = soup.find_all('loc')
        urls = [url.text for url in urls_raw]
        inner_url = []
        for i in urls:
            file_extension = i.split('.')[-1].lower()
            if file_extension == "xml":
                
                r = requests.get(i)
                soup = BeautifulSoup(r.content, features='xml')
                urls_raw = soup.find_all('loc')
                urls1 = [url.text for url in urls_raw]
                inner_url+=urls1
        
        urls = set(inner_url).symmetric_difference(set(urls))
        urls = list(urls)
        return urls
        

    def get_urls(self):
        print("===============================================================using inner links")
        print("inner url--------------------------------",self.base_url)
        inner_urls = asyncio.run(self.using_inner_links())
        if len(inner_urls) < 3:
            # print("===========================================================using sitemap")
            # print("sitemap url,----------------------------",self.sitemap_xml)
            # site_map_urls = self.using_sitemap()
            # if len(site_map_urls) == 0:
            #     print("sitemap inner urls========================================")
            #     inner_sitemap_urls = asyncio.run(self.using_inner_links(self.sitemap_xml))
            #     if len(inner_sitemap_urls) < 3:
            #         return site_map_urls
            #     else:
            #         return inner_urls
            # else:
            #     return inner_urls
            return []
        else:
            return inner_urls


    def get_source(self):
        return self.base_url
    
    
    def get_docs(self):
        return self.get_urls()

# Define an embedding function
embed_model = HuggingFaceEmbedding(model_name="thenlper/gte-base",device="cpu")

# Function to normalize text using NFKC
def nfkc_normalize(text: str) -> str:
    return unicodedata.normalize("NFKC", text)

async def scrape_page(url: str, proxy: Optional[str] = None) -> str:
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()
        
        if proxy:
            await page.set_proxy({"server": proxy})
        
        await page.goto(url,timeout=60000)
        
        page_source = await page.content()
        elements = partition_html(text=page_source)
        text = " ".join([str(el) for el in elements])
        
        await page.close()
        await browser.close()
        
        return text


# Function to scrape the page
async def scrape_web_page(url):
    try:
        text = await scrape_page(url)
        return text
    except:
        return ""


def get_urls(base_url:str = "https://worktual.co.uk/"):
    a = URLIngestion(base_url=base_url)
    urls = a.get_docs()
    return urls

count = 0 
missed_count = 0


# coroutine used for a task
class scrappedCount:
    scraped_count = 0


async def task_coro(url):
    # report a message
    global count
    count += 1
    print(f'>task {url} executing , count {count}')
    # sleep for a

    doc = await scrape_web_page(url)
    # docs = [document.text for document in doc]
    if doc != "":
        print("URL : ",url,"-->",scrappedCount.scraped_count)
        # print("document------>",doc)
        scrappedCount.scraped_count+=1
    return doc



def generate_batch(lst, batch_size):
    """  Yields batch of specified size """
    for i in range(0, len(lst), batch_size):
        yield lst[i : i + batch_size]
 
# coroutine used for the entry point
async def crawl(batch):
    with Timer(text="\nTotal batch crawl time: {:.1f}"):
        # report a message
        print('batch starting')

        # create many tasks
        tasks = [task_coro(url=url) for url in batch]
        
        # run the tasks
        values = await asyncio.gather(*tasks)

        # report a message
        print('batch done')
        # print("values=========================================",values)
        return values

def start_crawling(urls, batch_size = 25,count = 0):
    docs = []
    gen = generate_batch(urls, batch_size)
    progress = 100/(count/25)
    total_progress = progress
    gen = list(gen) 
    print("-------------------gen------------",gen)
    
    no_of_batch = len(gen)
        
    print("-----------------no of batch----------",no_of_batch)
    for i in range(no_of_batch):
        values = asyncio.run(crawl(batch=gen[i]))
        docs.extend(values)
        if i == len(gen)-1:
            #  redis_cli.rpush("scrap_progress",100)
             print("progess: ----------------------------------------------",100)
        else:
            #  redis_cli.rpush("scrap_progress",total_progress)
             
             print("progess: ----------------------------------------------",total_progress)
        total_progress+=progress
        print("===============================batch done=============================")
    print("type=================================================== ",type(docs))

    
    return docs

def remove_language_code(url):
    print("before removing language code-----------------------",url)
    parsed_url = urlparse(url)

    path_components = parsed_url.path.split('/')

    language_code = None
    country_code = None

    for component in path_components:
        if len(component) == 2:
            if not language_code:
                language_code = component
            elif not country_code:
                country_code = component
            else:
                break
    if language_code:
        index_language = path_components.index(language_code)
        path_components = path_components[:index_language]
    if country_code:
        index_country = path_components.index(country_code)
        path_components = path_components[:index_country]

    base_url = f"{parsed_url.scheme}://{parsed_url.netloc}/"

    return base_url


class Data1(BaseModel):
    url_text: str
    domain_id:int
    websiteId:str

import re
def segment_text(text, chunk_size):
    # Tokenize the text into sentences and words
    sentences = re.split(r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?)\s', text)
    segments = []
    current_segment = []

    word_count = 0
    for sentence in sentences:
        sentence_words = sentence.split()
        word_count += len(sentence_words)

        # Check if the word count reaches approximately 300 or a sentence is completed near 300 words
        if word_count >= chunk_size or (word_count >= chunk_size - 50 and len(current_segment) > 0):
            segments.append(' '.join(current_segment))
            current_segment = sentence_words
            word_count = len(sentence_words)
        else:
            current_segment.extend(sentence_words)

    # Add the last segment
    if current_segment:
        segments.append(' '.join(current_segment))

    return segments



@app.post("/scrape1/")
def create_embeddings(data:Data1):
    try:
        print("user link---------------------------",data.url_text)
        print("domain Id---------------------------",data.domain_id)
        print("website Id---------------------------",data.websiteId)

        if data.url_text.startswith("www"):
            data.url_text = "https://"+data.url_text
        print("after removing language code==============",data.url_text)
        urls = get_urls(data.url_text)
        print("all urls==================",urls)
        url_length = len(list(urls))
        print(f"URLs count : {url_length}")
        if len(urls)==0:
            return {"domainId":data.domain_id,"wesiteId":data.websiteId,"message": "failure"}
        docs = start_crawling(urls,batch_size=25,count=len(urls))
        scrappedCount.scraped_count = 0
        
        service_context = ServiceContext.from_defaults(embed_model=embed_model,llm = None)
        # service_context = ServiceContext.from_defaults(embed_model=embed_model,llm = None,chunk_size=300, chunk_overlap=50)
        print("len of docs-----------------",len(docs))
        text_docs = "".join(docs)

        segmented_texts = segment_text(text_docs,256)
        
        
        # print(text_docs)
        # documents = [llama_index.Document(text=list(i)[0][1])for i in docs]
        documents = [llama_index.Document(text=i) for i in segmented_texts]
        # print("=============================",documents)

        db = chromadb.PersistentClient(path=f"./embedded_data_v2/{data.domain_id}/{data.websiteId}")
        chroma_collection = db.get_or_create_collection("quickstart")
        vector_store = ChromaVectorStore(chroma_collection=chroma_collection)
        storage_context = StorageContext.from_defaults(vector_store=vector_store)
        VectorStoreIndex.from_documents(documents, storage_context=storage_context,
                                        service_context=service_context,
                                        show_progress=True)
        
        print(f"embedded files saved in ./embedded_data_v2/{data.domain_id}/{data.websiteId}folder")
        return {"domainId":data.domain_id,"wesiteId":data.websiteId,"message": "success"}

    except Exception as e:
        print(e)
        return {"domainId":data.domain_id,"wesiteId":data.websiteId,"message": "failure"}


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=5586)
    
    
    
    


