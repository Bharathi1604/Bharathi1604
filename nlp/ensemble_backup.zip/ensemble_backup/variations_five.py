import aiohttp
import asyncio

class RequestHandler:
    def __init__(self, temp_question, answer, company_name, company_type):
        self.temp_question = temp_question
        self.answer = answer
        self.company_name = company_name
        self.company_type = company_type
        self.url = "http://46.43.144.145:7002/variation_1"

    async def make_request(self):
        payload = {
            "question": self.temp_question,
            "answer": self.answer,
            "company": self.company_name,
            "domain": self.company_type
        }

        async with aiohttp.ClientSession() as session:
            async with session.post(self.url, json=payload) as response:
                response_data = await response.json()
                return response_data

    async def query_augmentation(self):
        variation = await self.make_request()
        return variation

async def main():
    temp_question = "what is worktual"
    answer = "worktual is an AI-based telecommunication service"
    company_name = "worktual"
    company_type = "communication"

    request_handler = RequestHandler(temp_question, answer, company_name, company_type)
    result = await request_handler.query_augmentation()
    print([result])


# Run the asynchronous code within an event loop
loop = asyncio.get_event_loop()
loop.run_until_complete(main())