
class WordSplitter:
    def __init__(self, chunk_size=10, overlap=5):
        self.chunk_size = chunk_size
        self.overlap = overlap

    def split_words(self, text):
        return self._split_words_recursive(text)

    def _split_words_recursive(self, text):
        # Base case: if the text is empty, return an empty list
        if not text:
            return []

        # If the remaining text is less than the minimum chunk size, consider it as one chunk
        if len(text) <= self.chunk_size:
            return [text]

        # Split the text into words
        words = text.split()

        result_chunks = []
        current_chunk = ""
        i = 0

        while i < len(words):
            current_chunk += " "+words[i]
            if current_chunk.count(" ") > self.chunk_size:
                result_chunks.append(current_chunk)
                current_chunk = ""
                i -= self.overlap
            i+=1

        return result_chunks
    
input_text = """Contact Sales UK 0203 444 00010203 444 0001USA+ 1 (518) 3944040Canada + 1 (647) 4935050 Australia + 61 (352) 345050Contact us My Account Contact Sales UK 0203 444 0001USA+ 1 (518) 3944040Canada + 1 (647) 4935050 Australia + 61 (352) 345050Contact us Web App My Account Partners Affiliates Login Products Solutions Pricing Why Worktual Resources Products Solutions Pricing Why Worktual Resources Get started for FREE ! Powering business with CXAI technology Batman & Robin, Thelma & Louise, Jobs & Wozniak – everyone needs a trusted companion From live chat to chatbots, our AI-powered Xaia systems will support your customers anytime, anywhere. We believe that every business website should have a Worktual customer-support chatbox so customers can get the trusted help they need, for a seamless and improved customer-service experience More chat, less bot! Most chatbots are too basic, too robotic, and simply don’t have enough information data points to really be useful. They frustrate already frustrated customers looking for help and support. So after 20 years of disrupting the mobile communications industry we’re looking to disrupt and improve the customer-support sector. Choose your plan Introducing Xaia We've developed three supercharged customer-support chatbox systems powered by Worktual's CXAI technology to offer better customer experience and engagement. From enhanced live chat with agents, an advanced FAQ/rule-based chatbot, and optimised conversational-AI problem solving, our supercharged Xaia chatbox systems support your customers, agents, and business better than anything else on the market. We'd choose a supercharged Xaia chatbox over a basic robotic chatbot any day. Xaia is your new ‘employee of the month’...every month! Test our bot Find out more Xaia offers stand alone systems or can be upgraded to a Contact Centre platform offering full omnichannel support – and of course, can be fully customised for your bespoke business needs. So only pay for what you need and you can upgrade at any time as we help your business to grow. Xaia1 Xaia2 Xaia3 Xaia1 is your FREE enhanced live chat support for your website Worktual’s Xaia1 chatbox system offers an enhanced live chat solution that is easy to install and directly connects customers with agents to resolve customer-support issues efficiently and effectively. Our proactive system lets agents engage with customers when they most need it to offer trusted help and support, which lowers frustration and increases customer experience and satisfaction. Oh and did we mention it's free forever? Yep, you read that right...free forever! Learn more Xaia2 is your advanced rule-based chatbot that breaks all the rules! The Worktual Xaia2 chatbot system is easy to use and can be set up in under 60 mins so you can get started today. Worktual’s CXAI technology will scan your website and pull all relevant information so Xaia2 can start answering customer queries asap. New queries will be monitored and added to Xaia2’s knowledge base to consistently increase resolution rate, lower agent involvement, and improve the customer experience. Xaia2 gets smarter, your costs go down, and your 5-star ratings go up! Learn more Xaia3 is your supercharged conversational-AI chatbot The Worktual Xaia3 chatbot system offers the ultimate supercharged customer experience with human-like conversations. Worktual’s CXAI technology utilises the full range of conversational AI and NLP capabilities to give personalised customer service to optimise engagement and resolution – that gets better every day. The result: customers get speedy resolution on their channel of choice and agents are free to focus on more complicated queries. Learn more Discover just how easy Worktual's AI-powered Xaia systems can supercharge your communications Choose your plan Powering business with CXAI technology Choose a Xaia chatbox only or upgrade to an omnichannel Contact Centre platform – it's as easy as 1, 2, 3! Free forever Xaia Free live chat Unlimited sessions Unlimited agents Smart reply First 100 session free Xaia Rule-based chatbot 10,000 sessions Agent assist Unlimited agents Transfer to live agent Pre-built templates, knowledge base, data scraping Semantic search Intent change Transcriptions Xaia Conversational AI bot Unlimited sessions Agent assist Unlimited agents Transfer to live agent Machine learning training, Retrieval augmented generation (RAG) Semantic search Multiple intents Transcriptions See the full list of features """

result_chunks = WordSplitter(300,5).split_words(input_text)

print(result_chunks)
