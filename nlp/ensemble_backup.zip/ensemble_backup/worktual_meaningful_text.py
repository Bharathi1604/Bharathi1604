import re

def segment_text(text, chunk_size):
    # Tokenize the text into sentences and words
    sentences = re.split(r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?)\s', text)
    segments = []
    current_segment = []

    word_count = 0
    for sentence in sentences:
        sentence_words = sentence.split()
        word_count += len(sentence_words)

        # Check if the word count reaches approximately 300 or a sentence is completed near 300 words
        if word_count >= chunk_size or (word_count >= chunk_size - 50 and len(current_segment) > 0):
            segments.append(' '.join(current_segment))
            current_segment = sentence_words
            word_count = len(sentence_words)
        else:
            current_segment.extend(sentence_words)

    # Add the last segment
    if current_segment:
        segments.append(' '.join(current_segment))

    return segments


with open("worktual.txt","r") as f:
    worktual_text = f.read()


# segmented_text = segment_text(worktual_text,256)


from semantic_text_splitter import HuggingFaceTextSplitter
from tokenizers import Tokenizer

# Maximum number of tokens in a chunk
# max_characters = 300
# Optionally can also have the splitter not trim whitespace for you
tokenizer = Tokenizer.from_pretrained("bert-base-uncased")
splitter = HuggingFaceTextSplitter(tokenizer, trim_chunks=False)

sentences = splitter.chunks(worktual_text, 50)

# i  = 0
result_chunks = []
current_chunk = ""
for i in range(len(sentences)):
    current_chunk += f" {sentences[i]}"
    if current_chunk.count(" ") >= 256:
        result_chunks.append(current_chunk)
        # print(current_chunk)
        current_chunk = f"{sentences[i-2]} {sentences[i-1]} {sentences[i]}"

print("-=-----------------------------------------------",len(result_chunks))

# print(segmented_text[15])

import requests
from time import sleep
count = 1
for text in result_chunks:
    resposne = requests.post("http://46.43.144.145:7010/informative_webscrap",json={"text":text})
    meaningfull_data = resposne.json()["response"]
    print(meaningfull_data)
    with open("worktual_meaningful_text.txt","a") as f:
        f.write(f"raw text-------> {text}\n\n\nmeaningful text --------> {meaningfull_data}\n\n\n")
    print("=======================================",count)
    count+=1











