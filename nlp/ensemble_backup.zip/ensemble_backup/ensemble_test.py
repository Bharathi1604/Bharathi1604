import nltk
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity


class WordSplitter:
    def __init__(self, chunk_size=200, overlap=0):
        self.chunk_size = chunk_size
        self.overlap = overlap

    def split_words(self, text):
        return self._split_words_recursive(text)

    def _split_words_recursive(self, text):
        # Base case: if the text is empty, return an empty list
        if not text:
            return []

        # If the remaining text is less than the minimum chunk size, consider it as one chunk
        if len(text) <= self.chunk_size:
            return [text]

        # Split the text into words
        words = text.split()

        result_chunks = []
        current_chunk = ""
        i = 0

        while i < len(words):
            current_chunk += " "+words[i]
            if current_chunk.count(" ") > self.chunk_size:
                result_chunks.append(current_chunk)
                current_chunk = ""
                i -= self.overlap
            i+=1

        return result_chunks

class SentenceSplitter:
    def __init__(self, chunk_size=200, overlap=0):#overlap sentence like 1,2.... which mean one, two complete sentence 
        self.chunk_size = chunk_size
        self.overlap = overlap

    def split_sentences(self, text):
        return self._split_sentences_recursive(text)

    def _split_sentences_recursive(self, text):
        # Base case: if the text is empty, return an empty list
        if not text:
            return []

        # If the remaining text is less than the minimum chunk size, consider it as one chunk
        if len(text) <= self.chunk_size:
            return [text]

        # Split the text into words
        sentences =  nltk.sent_tokenize(text)

        result_chunks = []
        current_chunk = ""
        i = 0

        while i < len(sentences):
            current_chunk += " "+sentences[i]
            if current_chunk.count(" ") > self.chunk_size:
                result_chunks.append(current_chunk)
                current_chunk = ""
                i -= self.overlap
            i+=1

        return result_chunks
    


class SentenceEmbedder:
    def __init__(self, model_paths):
        self.models = [SentenceTransformer(model_path,device = "cpu") for model_path in model_paths]

    def generate_embeddings(self, sentences):
        embeddings_list = [model.encode(sentences) for model in self.models]
        return embeddings_list

    def find_most_similar_sentence(self, query, sentences, sentence_embeddings_list, top_n=1):
        query_embeddings = [model.encode([query])[0] for model in self.models]
        top_similar_sentences = []

        for embeddings in sentence_embeddings_list:
            similarities = cosine_similarity([query_embeddings.pop(0)], embeddings)[0]
            top_similar_indices = similarities.argsort()[-top_n:][::-1]
            print(top_similar_indices)
            top_similar_sentences.extend([sentences[idx] for idx in top_similar_indices])
            print([sentences[idx] for idx in top_similar_indices])

        return top_similar_sentences

def write_file(file,data):
    with open(file,"a")as f:
        f.writelines(data)

import re

def segment_text(text, chunk_size):
    # Tokenize the text into sentences and words
    sentences = re.split(r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?)\s', text)
    segments = []
    current_segment = []

    word_count = 0
    for sentence in sentences:
        sentence_words = sentence.split()
        word_count += len(sentence_words)

        # Check if the word count reaches approximately 300 or a sentence is completed near 300 words
        if word_count >= chunk_size or (word_count >= chunk_size - 50 and len(current_segment) > 0):
            segments.append(' '.join(current_segment))
            current_segment = sentence_words
            word_count = len(sentence_words)
        else:
            current_segment.extend(sentence_words)

    # Add the last segment
    if current_segment:
        segments.append(' '.join(current_segment))

    return segments


if __name__ == "__main__":


    with open("lux residential.txt","r") as f:
        worktual_text = f.read()

    # print("=======================================",worktual_text)
    # Word_split_text_256 = WordSplitter(256,50).split_words(worktual_text)
    # sentence_split_text_256 = SentenceSplitter(256,1).split_sentences(worktual_text)

    # Word_split_text_512 = WordSplitter(512,50).split_words(worktual_text)
    # sentence_split_text_512 = SentenceSplitter(512,1).split_sentences(worktual_text)

    # Word_split_text_1024 = WordSplitter(1024,50).split_words(worktual_text)
    # sentence_split_text_1024 = SentenceSplitter(1024,1).split_sentences(worktual_text)

    # Word_split_text_256_n = WordSplitter(256).split_words(worktual_text)
    # sentence_split_text_256_n = SentenceSplitter(256,1).split_sentences(worktual_text)

    # Word_split_text_512_n = WordSplitter(512).split_words(worktual_text)
    # sentence_split_text_512_n = SentenceSplitter(512).split_sentences(worktual_text)

    # Word_split_text_1024_n = WordSplitter(1024).split_words(worktual_text)
    # sentence_split_text_1024_n = SentenceSplitter(1024).split_sentences(worktual_text)

    segment_text_sentences = segment_text(worktual_text,256)

    for i in segment_text_sentences:
        print(i,"\n\n")



    model_paths = [
        'paraphrase-MiniLM-L6-v2',  # Replace with your desired model paths
        'all-mpnet-base-v2',
        "BAAI/bge-base-en-v1.5",
        "sentence-transformers/all-MiniLM-L6-v2",
        "thenlper/gte-base"  # Add additional model paths if needed
    ]
    print("=======================================")


    sentence_embedder = SentenceEmbedder(model_paths)

    print("=======================================")


    sentence_embeddings_list_word = sentence_embedder.generate_embeddings(segment_text_sentences)
    # sentence_embeddings_list_sentence = sentence_embedder.generate_embeddings(sentence_split_text_256)
    while True:
        query = input("Enter the Query ---- > ")
        print("Query----------------------------->")
        write_file("worktual_sentence_split.txt","\n\nword_split_256----------"+query+"\n\n")
        most_similar_sentences = sentence_embedder.find_most_similar_sentence(query, segment_text_sentences, sentence_embeddings_list_word)
        unique_sentences = list(set(most_similar_sentences))
        write_file("worktual_sentence_split.txt","\n\n---------------".join(unique_sentences))
        print("word_split_256-----------------------------------",unique_sentences)



        # write_file("sentence_split_256.txt","\nsentence_split_256----------"+query+"\n")
        # most_similar_sentences = sentence_embedder.find_most_similar_sentence(query, sentence_split_text_256, sentence_embeddings_list_sentence)
        # unique_sentences = list(set(most_similar_sentences))
        # write_file("word_split_256.txt","\n\n".join(unique_sentences))
        # print("sentence_split_256-----------------------------------",unique_sentences)






