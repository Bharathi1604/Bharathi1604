from semantic_text_splitter import HuggingFaceTextSplitter
from tokenizers import Tokenizer

tokenizer = Tokenizer.from_pretrained("bert-base-uncased")
splitter = HuggingFaceTextSplitter(tokenizer, trim_chunks=False)


class SentenceSplitter:
    def __init__(self, chunk_size=200, overlap=0):#overlap sentence like 1,2.... which mean one, two complete sentence 
        self.chunk_size = chunk_size
        self.overlap = overlap

    def split_sentences(self, text):
        return self._split_sentences_recursive(text)

    def _split_sentences_recursive(self, text):
        # Base case: if the text is empty, return an empty list
        if not text:
            return []

        # If the remaining text is less than the minimum chunk size, consider it as one chunk
        if len(text) <= self.chunk_size:
            return [text]

        # Split the text into words
        sentences = splitter.chunks(text, 30)
        print("============================================",len(sentences))


        result_chunks = []
        current_chunk = ""
        i = 0

        while i < len(sentences):
            current_chunk += " "+sentences[i]
            if current_chunk.count(" ") > self.chunk_size:
                result_chunks.append(current_chunk)
                # print(current_chunk)
                current_chunk = ""
                i -= self.overlap
            i+=1

        return result_chunks
    


with open("worktual.txt","r") as f:
    worktual_text = f.read()


sentences = splitter.chunks(worktual_text, 50)

# i  = 0
result_chunks = []
current_chunk = ""
# while i < len(sentences):
#     current_chunk += f" {sentences[i]}"
#     if current_chunk.count(" ") >= 256:
#             result_chunks.append(current_chunk)
#             # print(current_chunk)
#             current_chunk = ""
#             i -= 2
#     i+=1


for i in range(len(sentences)):
    current_chunk += f" {sentences[i]}"
    if current_chunk.count(" ") >= 256:
        result_chunks.append(current_chunk)
        # print(current_chunk)
        current_chunk = f"{sentences[i-2]} {sentences[i-1]} {sentences[i]}"




with open("sample2.txt","a") as f:
    f.write("\n\n".join(result_chunks))





# chunks = SentenceSplitter(256,2).split_sentences(worktual_text)

# print("=========================================================",chunks)

# for i in chunks:
#     with open("worktual_overlap.txt","a") as f:
#         f.write(f"\n\n{i}\n\n")

# print("=========================================================")
    



