import nltk
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

class SentenceEmbedder:
    def __init__(self, model_paths):
        self.models = [SentenceTransformer(model_path,device = "cpu") for model_path in model_paths]

    def generate_embeddings(self, sentences):
        embeddings_list = [model.encode(sentences) for model in self.models]
        return embeddings_list

    def find_most_similar_sentence(self, query, sentences, sentence_embeddings_list, top_n=1):
        query_embeddings = [model.encode([query])[0] for model in self.models]
        top_similar_sentences = []

        for embeddings in sentence_embeddings_list:
            similarities = cosine_similarity([query_embeddings.pop(0)], embeddings)[0]
            top_similar_indices = similarities.argsort()[-top_n:][::-1]
            print(top_similar_indices)
            top_similar_sentences.extend([sentences[idx] for idx in top_similar_indices])
            print([sentences[idx] for idx in top_similar_indices])

        return top_similar_sentences




if __name__ == "__main__":


    with open("worktual.txt","")

    telecommunication_sentences = [
    "Telecommunication serves as a cornerstone for global connectivity, enabling communication between individuals worldwide.",
    "The advent of 5G technology promises faster speeds and lower latency, revolutionizing how we communicate and access information.",
    "Fiber-optic cables, with their high-speed data transmission capabilities, form the backbone of modern telecommunication networks.",
    "Satellite communication plays a pivotal role in delivering broadcasting, navigation, and internet services on a global scale.",
    "The Internet of Things (IoT) relies on telecommunication infrastructure to interconnect and enable communication between devices.",
    "Secure telecommunication protocols and encryption methods ensure data privacy and confidentiality during transmission.",
    "Telecommunication regulations and standards govern network operations to ensure fair competition and consumer protection.",
    "Telecommunication companies invest in research and development to innovate and meet the evolving needs of users.",
    "Emerging technologies, such as artificial intelligence and blockchain, are integrated into telecommunication systems for enhanced functionality.",
    "Continuous advancements in telecommunication contribute to the evolution of smart cities and interconnected digital ecosystems."
]

    model_paths = [
        'paraphrase-MiniLM-L6-v2',  # Replace with your desired model paths
        'all-mpnet-base-v2',
        "BAAI/bge-base-en-v1.5",
        "sentence-transformers/all-MiniLM-L6-v2",
        "thenlper/gte-base"  # Add additional model paths if needed
    ]

    query = "Your single query goes here"

    sentence_embedder = SentenceEmbedder(model_paths)
    sentence_embeddings_list = sentence_embedder.generate_embeddings(telecommunication_sentences)

    most_similar_sentences = sentence_embedder.find_most_similar_sentence(query, telecommunication_sentences, sentence_embeddings_list)
    unique_sentences = list(set(most_similar_sentences))

    print(unique_sentences)

