from redis import Redis

rc = Redis(
    host='127.0.0.1',
    port=6379,
    db=0,
    decode_responses=True
)

import json
email= "sasik@123.com"
name = "sasi"
age = 20

rc.hset(email, mapping={
    'name': name,
    "age" : age,
    "email":email
})

print("-------------")
rc.hset("nlp", mapping={
    email:json.dumps(rc.hgetall(email))
})


res = rc.hgetall('nlp')

print(res)