from llama_index.storage.storage_context import StorageContext
from llama_index import VectorStoreIndex,ServiceContext
from llama_index.vector_stores import ChromaVectorStore
from llama_index.embeddings import HuggingFaceEmbedding
from fastapi.middleware.cors import CORSMiddleware
from playwright.async_api import async_playwright
from usp.tree import sitemap_tree_for_homepage
from urllib.parse import urlparse
from pydantic import BaseModel
from datetime import datetime
from bs4 import BeautifulSoup
from codetiming import Timer
from fastapi import FastAPI
from typing import Optional
from copy import copy
import llama_index
import unicodedata
import chromadb
import asyncio
import logging
import uvicorn
import torch
import redis
import json
import os
import gc

# redis_cli = Redis(host="localhost",port=6379)

rc = redis.Redis(
    host='10.150.0.250',
    port=6379,
    db=0,
    password='vectone250',
    decode_responses=True
)

logger = logging.getLogger(__name__)
TIME_OUT = 120000

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Set the allowed origins. You can customize this based on your needs.
    allow_credentials=True,  # Set to True if your API allows credentials (e.g., cookies, authentication headers)
    allow_methods=["*"],  # Set the allowed HTTP methods. You can customize this based on your needs.
    allow_headers=["*"],  # Set the allowed HTTP headers. You can customize this based on your needs.
)

os.environ["TOKENIZERS_PARALLELISM"] = "false"
# embed_model = HuggingFaceEmbedding(model_name="BAAI/bge-small-en-v1.5",device="cpu")
embed_model = HuggingFaceEmbedding(model_name="BAAI/bge-large-en",device="cpu")

def nfkc_normalize(text: str) -> str:
    return unicodedata.normalize("NFKC", text)

chroma_client = chromadb.EphemeralClient()
# define embedding function

class URLIngestion():

    def __init__(self, base_url):
        self.base_url = base_url
        # self.url = self.remove_language_code(base_url)

    # def remove_language_code(url):
    #     print("\nBefore removing language code-----------------------",url)
    #     parsed_url = urlparse(url)

    #     path_components = parsed_url.path.split('/')

    #     language_code = None
    #     country_code = None

    #     for component in path_components:
    #         if len(component) == 2:
    #             if not language_code:
    #                 language_code = component
    #             elif not country_code:
    #                 country_code = component
    #             else:
    #                 break
    #     if language_code:
    #         index_language = path_components.index(language_code)
    #         path_components = path_components[:index_language]
    #     if country_code:
    #         index_country = path_components.index(country_code)
    #         path_components = path_components[:index_country]

    #     base_url = f"{parsed_url.scheme}://{parsed_url.netloc}/"

    #     return base_url


    def clean_urls(self, urls):
        clean_words = ["youtube", "cloudflare", "linkedin", "facebook", "instagram", "twitter", "play.google.com"]
        final_urls = set()
        for url in urls:
            temp_url = copy(url).lower()
            flag = True
            for word in clean_words:
                if word in temp_url:
                    flag = False
                    break
            if flag:
                final_urls.add(url)
            else:
                print("removed urls ---------->", temp_url)
        return list(final_urls)
    # ---------------------------------------------------------------------
    
    def using_sitemap(self,url=None):
        print("Inside using_sitemap ---------->",self.base_url)
        tree = sitemap_tree_for_homepage(self.base_url)
        # print(tree)
        # print("---------------------")
        urls = [page.url for page in tree.all_pages()]
        url = list(set(urls))
        print("----------------------------------")
        print(url)
        print("Length of url ---------->",len(url))
        return url

    async def using_inner_links(self, url=None):
        print("\nInside Inner Links-------------------")
        async with async_playwright() as p:
            print("Inside using_inner_links ---------->",self.base_url)
            browser = await p.chromium.launch()
            context = await browser.new_context(
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36"
            )
            page = await context.new_page()
            try:
                if url is None:
                    await page.goto(self.base_url, timeout=60000)
                else:
                    print("Inside else part of using_inner_links ---------->",url)
                    await page.goto(url, timeout=60000)
                
                inner_links = await page.query_selector_all('a[href^="https://"]')
                url_list = list(set([await link.get_attribute('href') for link in inner_links]))

                print("Length of URL list ---------->",len(url_list))

                return url_list
            finally:
                await browser.close()
            
    def get_urls(self):
        print("\nInside get_urls function-----------")
        print("BASE URL ---------->",self.base_url)
        inner_urls = asyncio.run(self.using_inner_links())
        sitemap_urls = self.using_sitemap()
        # if len(sitemap_urls) == 0:
        #     sitemap_urls = asyncio.run(self.get_sitemap_from_index_url())
        print("Length of Inner URL ---------->",len(inner_urls))
        print("Length of sitemap URL ---------->",len(sitemap_urls))
        if len(inner_urls) <= len(sitemap_urls) and len(sitemap_urls) <= 1100:
            return sitemap_urls
        else:
            return inner_urls
    
    def get_docs(self):
        return self.get_urls()
    
async def scrape_page(url: str, proxy: Optional[str] = None) -> str:
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        context = await browser.new_context(user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36')
        page = await context.new_page()
        await page.goto(url)
        await page.wait_for_timeout(60000)
        content = await page.content()
        soup = BeautifulSoup(content, 'html.parser')
        text_content = soup.get_text(separator='\n', strip=True)
        # with open("lyca_faq_dec_6.txt","w") as f:
        #     f.write(text_content)
        # print(text_content)
        await browser.close()
        return text_content
    
# Function to scrape the page
async def scrape_web_page(url):
    try:
        text = await scrape_page(url)
        return text
    except:
        return ""

def get_urls(base_url):
    a = URLIngestion(base_url=base_url)
    urls = a.get_docs()
    return urls

count = 0 
missed_count = 0

class scrappedCount:
    scraped_count = 0

async def task_coro(url):
    global count
    count += 1
    print(f'>task {url} executing , count {count}')
    # sleep for a

    doc = await scrape_web_page(url)
    # docs = [document.text for document in doc]
    if doc != "":
        print("\nURL : ",url,"-->",scrappedCount.scraped_count)
        # print("document------>",doc)
        scrappedCount.scraped_count+=1
    return doc

def generate_batch(lst, batch_size):
    """  Yields batch of specified size """
    for i in range(0, len(lst), batch_size):
        yield lst[i : i + batch_size]

# coroutine used for the entry point
async def crawl(batch):
    with Timer(text="\nTotal batch crawl time: {:.1f}"):
        print('===============batch starting===============')

        # create many tasks
        tasks = [task_coro(url=url) for url in batch]
        
        # run the tasks
        values = await asyncio.gather(*tasks)

        # report a message
        print('\n===============batch done===============')
        # print("values=========================================",values)
        return values

def start_crawling(urls,domain_id,websiteId,ext, batch_size = 25,count = 0,batch_count = 0):
    docs = []
    gen = generate_batch(urls, batch_size)
    progress = 85/(count/25)
    total_progress = progress
    gen = list(gen) 
    print("\n\nTotal Batch-------------",gen)
    
    no_of_batch = len(gen)

    if batch_count < len(gen) and batch_count != 0:
        no_of_batch = batch_count
        
    print("\nNumber of batch----------",no_of_batch)
    for i in range(no_of_batch):
        values = asyncio.run(crawl(batch=gen[i]))
        docs.extend(values)
        if i == len(gen)-1:
            #  redis_cli.rpush("scrap_progress",100)
            print()
            print()
            progress_data = {"websiteId":websiteId,"domainId":domain_id,"ext":ext,"progress":85}
            progress_data = json.dumps(progress_data)
            print()
            print()
            rc.rpush("webscrap_res_1",progress_data)
            print("\nProgess:----------------------------------------------",85)
        else:
            #  redis_cli.rpush("scrap_progress",total_progress)
            print()
            print()
            progress_data = {"websiteId":websiteId,"domainId":domain_id,"ext":ext,"progress":total_progress}
            progress_data = json.dumps(progress_data)
            print()
            print()
            rc.rpush("webscrap_res_1",progress_data)
            print("\nProgess---------------------------------------------",total_progress)
        total_progress+=progress
        print("\n===============================batch done=============================")
    print("\nType of docs=================================================== ",type(docs))
    
    return docs


class Data1(BaseModel):
    url_text: str
    domain_id:int
    websiteId:str
    ext:str


@app.post("/scrape")
def create_embeddings(data:Data1):
    try:
        batch_count = 40
        print("\nUser Given Link---------------------------",data.url_text)
        print("\nDomain ID---------------------------",data.domain_id)
        print("\nWebsite ID---------------------------",data.websiteId)
        print("\nExtension ID---------------------------",data.ext)

        if data.url_text.startswith("www"):
            data.url_text = "https://"+data.url_text
        print("\nAfter appending https ---------->",data.url_text)
        urls = get_urls(data.url_text)
        print("\nAll URL's---------->",urls)
        url_length = len(list(urls))
        print(f"\nURL's count : {url_length}")
        if len(urls)==0:
            print()
            print()
            return {"domainId":data.domain_id,"wesiteId":data.websiteId,"message": "Please upload the knowledge base in CSV or pdf format, as this site does not allow data scraping."}
        
        imp_page = ["faq","FAQ","FAQs","support","Support","help","Help","HELP","products","product","pricing","price","cost","aboutus","about-us","Aboutus","solution","solutions","plans","plan"]

        present = False
        for i in imp_page:
            for j in urls:
                if i in j:
                    present = True
                    break
                elif len(urls)<20 and (i not in j):
                    present = True
                    break
            if present == True:
                break

        if present == True:
        
            docs = start_crawling(urls,domain_id=data.domain_id,websiteId=data.websiteId,ext = data.ext,batch_size=25,count=len(urls),batch_count = batch_count)
            scrappedCount.scraped_count = 0
            
            service_context = ServiceContext.from_defaults(embed_model=embed_model,llm = None,chunk_size=300, chunk_overlap=50)
            # service_context = ServiceContext.from_defaults(embed_model=embed_model,llm = None,chunk_size=300, chunk_overlap=50)
            print("\nLength of docs-----------------",len(docs))
            # text_docs = "".join(docs)
            
            # docs = list(set(docs))
            
            # print(text_docs)
            # documents = [llama_index.Document(text=list(i)[0][1])for i in docs]
            documents = [llama_index.Document(text=i) for i in docs]
            # print("=============================",documents)

            # db = chromadb.PersistentClient(path=f"/root/web_crawl_live/llama_index_webcrawl/embedded_data_v2/{data.domain_id}/{data.websiteId}")
            db = chromadb.PersistentClient(path=f"embedded_data_v2/{data.domain_id}/{data.websiteId}")

            try:
                db.delete_collection(name="quickstart")
            except:
                pass
            chroma_collection = db.create_collection("quickstart")
            vector_store = ChromaVectorStore(chroma_collection=chroma_collection)
            storage_context = StorageContext.from_defaults(vector_store=vector_store)
            VectorStoreIndex.from_documents(documents, storage_context=storage_context,
                                            service_context=service_context,
                                            show_progress=True)
            torch.cuda.empty_cache()
            gc.collect()
            print(f"\nEmbedded files saved in /root/web_crawl_live/llama_index_webcrawl/embedded_data_v2/{data.domain_id}/{data.websiteId}folder")
            current_datetime = datetime.now()
            print(f"current time website_id : {data.websiteId} domain : {data.domain_id}---->",current_datetime)
            print("\nProgress-------------------------------",100)
            print()
            print()
            progress_data = {"websiteId":data.websiteId,"domainId":data.domain_id,"ext":data.ext,"progress":100}
            progress_data = json.dumps(progress_data)
            print()
            print()
            rc.rpush("webscrap_res_1",progress_data)
            print()
            print()
            return {"domainId":data.domain_id,"wesiteId":data.websiteId,"message": "success"}
        else:
            return {"domainId":data.domain_id,"wesiteId":data.websiteId,"message": "Sorry, the website cannot be reached. Please upload the knowledge base in the format of CSV or pdf."}

    except Exception as e:
        print(e)
        current_datetime = datetime.now()
        print()
        print()
        print(f"current time website_id : {data.websiteId} domain : {data.domain_id}---->",current_datetime)
        print()
        print()
        return {"domainId":data.domain_id,"wesiteId":data.websiteId,"message": "Sorry, the website cannot be reached. Please upload the knowledge base in the format of CSV or pdf."}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=4007)


