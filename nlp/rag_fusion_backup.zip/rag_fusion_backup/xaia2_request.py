import requests

import os

# System call
os.system("")

# Class of different styles
class style():
    BLACK = '\033[30m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'
    UNDERLINE = '\033[4m'
    RESET = '\033[0m'

while True:
    input_text = input(style.YELLOW+"Enter the Query : ")
    payload = {
    "query": input_text,
    "domainId": 10000,
    "websiteId": "00001"
    }

    response = requests.post("http://0.0.0.0:5099/knowledge_data",json=payload)
    response_data = response.json()

    context = response_data["result"]

    print(style.MAGENTA+context)

    payload = {
    "message_content": input_text,
    "content": context,
    "company_name": "grand cholan",
    "domain": "hotel"
    }

    response = requests.post("http://46.43.144.145:7020/rulebased_bot",json=payload)
    response_data = response.json()

    print(style.GREEN+response_data)