# s = "what is your name"


# if s[s.find("your")+4:s.find("your")+9] != " name":
#     s = s[:s.find("your")+4] + " company" + s[s.find("your")+4:]    

# print(s)


# s = """ 1. Numerical value
#         2. Quantity
#         3. Figure
#         4. Digit
# """


# s = s.split("\n")
# s_1 = []
# for i in s:
#     i = i.strip().replace("1.","").replace("2.","").replace("3.","").replace("4.","").replace("?","")
#     s_1.append(i)

# s = [i]


text = "what is lyca"

input_text=text
if input_text[-1] == "?":
    input_text = input_text[:-1]


print(input_text)