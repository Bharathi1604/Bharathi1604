import requests
from fastapi import FastAPI
from pydantic import BaseModel
import uvicorn

class Data(BaseModel):
    input_text:str

app = FastAPI()

@app.post("/get_response")
def getResponse(data:Data):
    input_text = data.input_text
    payload = {
    "query": input_text,
    "domainId": 10000,
    "websiteId": "00001"
    }

    response = requests.post("http://0.0.0.0:5099/knowledge_data",json=payload)
    response_data = response.json()

    context = response_data["result"]

    print(context)

    payload = {
    "message_content": input_text,
    "content": context,
    "company_name": "grand cholan",
    "domain": "hotel"
    }

    response = requests.post("http://46.43.144.145:7010/rulebased_bot",json=payload)
    response_data = response.json()

    return response_data

if __name__ == "__main__":
    uvicorn.run(app,host="192.168.13.112",port = 4000)