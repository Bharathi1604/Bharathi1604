import shutil
import logging
from pydantic import BaseModel
import os
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import requests
import uvicorn
from llama_index import VectorStoreIndex, SimpleDirectoryReader
from sentence_transformers import SentenceTransformer
import requests
import os
from llama_index import VectorStoreIndex,ServiceContext
from llama_index.vector_stores import ChromaVectorStore
from llama_index.storage.storage_context import StorageContext
from llama_index.embeddings import HuggingFaceEmbedding
import chromadb
from pathlib import Path
from llama_index import download_loader
import pickle
import aiohttp
import pandas as pd
import requests
import re
import asyncio
import os
from time import time
import datetime
import redis
import json
import os
import chardet
from detect_delimiter import detect
import urllib.request
from chardet.universaldetector import UniversalDetector
import urllib.parse


rc = redis.Redis(
    host='10.150.0.250',
    port=6379,
    db=0,
    password='vectone250',
    decode_responses=True
)


PDFReader = download_loader("PDFReader")


logger = logging.getLogger(__name__)
TIME_OUT = 180000
# embeddings = HuggingFaceEmbeddings(model_name='sentence-transformers/all-MiniLM-L6-v2') #, model_kwargs={'device': 'cpu'}
app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Set the allowed origins. You can customize this based on your needs.
    allow_credentials=True,  # Set to True if your API allows credentials (e.g., cookies, authentication headers)
    allow_methods=["*"],  # Set the allowed HTTP methods. You can customize this based on your needs.
    allow_headers=["*"],  # Set the allowed HTTP headers. You can customize this based on your needs.
)

logger = logging.getLogger(__name__)

model = SentenceTransformer('all-mpnet-base-v2',device = "cpu")
embed_model = HuggingFaceEmbedding(model_name="BAAI/bge-small-en-v1.5",device="cpu")
# PDFReader = download_loader("PDFReader")

class DataDict():
    user_data = {}

class Docs(BaseModel):
    pdf_links: str
    domainId:int
    websiteId:str
    ext:str
    companyName:str
    companyType:str



def generate_batch(lst, batch_size):
    """  Yields batch of specified size """
    for i in range(0, len(lst), batch_size):
        yield lst[i : i + batch_size]


# def generate_batch(lst, batch_size):
#     """  Yields batch of specified size """
#     batch = []
#     temp_list = []
#     count = 0
#     for i in range(len(lst)):
#         temp_list.append(lst[i])
#         count += 1
#         if count == batch_size:
#             batch.append(temp_list)
#             temp_list = []
#             count = 0
#     # batch.append(temp_list)
#     return batch



async def make_request(url, payload):
    async with aiohttp.ClientSession() as session:
        async with session.post(url, json=payload) as response:
            response_data = await response.json()
            return response_data



async def process(question,answer,websiteId,domain_id,company_name,company_type):
    # print(type(question),type(answer))
    if not isinstance(question,str):
        print("question missed")
    if not isinstance(answer,str):
        print("no anser for ",question)

    global final_question
    global final_answer
    # payload = {
    # "message_content": question,
    # "content": "Give 5 variations of user question. The variations should be in simple english as like real end user."
    # }

    # url = "http://46.43.144.145:8077/rulebased_bot"

    temp_question = question+"?"
    answer = answer.replace("’","'")
    # payload = {
    # "sentence":temp_question
    # }

    # url = "http://46.43.144.145:1011/variation"

    # payload = {
    # "question": temp_question,
    # "answer": answer
    # }

    # url = "http://46.43.144.145:7000/variation"




    #================payload with company==================#

    payload = {
    "question": temp_question,
    "answer": answer,
    "company": company_name,
    "domain": company_type
    }

    url = "http://46.43.144.145:7002/variation_1"

    #================payload with company==================#


    variation = await make_request(url, payload)

    pattern = r'\d+\.\s(.*?)\?'
    # Find all matches using re.findall
    variation_list = re.findall(pattern, variation)

    for i in range(len(variation_list)):
        if variation_list[i][-1] != "?":
            variation_list[i]+="?"

    if  len(variation_list) < 5:
        print("hi00000000000000000000000000000000000000000")
    # final_question.append(question)
    dict_id = str(domain_id)+"_"+websiteId
    DataDict.user_data[dict_id]["question"].extend([question]+variation_list)

    # final_answer.append(answer)
    list_temp = [answer for _ in range(len(variation_list))]
    DataDict.user_data[dict_id]["answer"].extend([answer]+list_temp)
    print("success --> ", question)




async def get_variation(question_list,answer_list,websiteId,domain_id,ext,company_name,company_type):

    que_batch = list(generate_batch(question_list,10))
    ans_batch = list(generate_batch(answer_list,10))
    print("Question list=======================>",question_list)
    print("Answer list=======================>",answer_list)
    print("total batch --> ",len(que_batch))
    progress = 95/ (len(question_list) / 10)
    total_progress = progress
    for i in range(len(que_batch)):
        questions = que_batch[i]
        answers = ans_batch[i]
        print(f"Batch {i+1} ================> ",len(questions)," links")
        tasks = [process(questions[j],answers[j],websiteId,domain_id,company_name,company_type) for j in range(len(questions))]
        # run the tasks
        await asyncio.gather(*tasks)
        if i == len(que_batch) - 1:
            progress_data = {"websiteId":websiteId,"domainId":domain_id,"ext":ext,"progress":95}
            progress_data = json.dumps(progress_data)
            rc.rpush("webscrap_res_1",progress_data)
            print("Progress: ----------------------------------------------", 95)
            print(progress_data)

        else:
            progress_data = {"websiteId":websiteId,"domainId":domain_id,"ext":ext,"progress":total_progress}
            progress_data = json.dumps(progress_data)
            rc.rpush("webscrap_res_1",progress_data)
            print("Progress: ----------------------------------------------", total_progress)
            print(progress_data)
        total_progress += progress
    return "success"


# async def main():
#     result = await get_variation()
#     return result
def get_file_paths(directory):
    file_paths = []  # To store the full paths of files
    
    # Getting the list of file names in the directory
    file_names = os.listdir(directory)
    
    # Generating the full paths for each file
    for filename in file_names:
        # Creating the full path of the file
        file_path = os.path.join(directory, filename)
        file_paths.append(file_path)  # Adding the file path to the list
    
    return file_paths

def pdf_embeddings(pdf_links,websiteId,domain_id,ext,company_name,company_type):
    try:
        print(pdf_links)
        print(domain_id)
        print(websiteId)

        print("Loading PDFs")
        response = requests.get(pdf_links)
        

        extension = pdf_links.split(".")[-1]
        print(extension)

        if extension == "pdf":
            final_path = f"./local_pdf_document_path/{domain_id}/{websiteId}/{pdf_links.split('/')[-1].split('.pdf')[0]}.pdf"
            final_directory = os.path.dirname(final_path)
            os.makedirs(final_directory, exist_ok=True)
            if response.status_code == 200:
                with open(final_path, 'wb') as file:
                    file.write(response.content)
                print(f"File downloaded successfully to {final_path}")
            else:
                print(f"Failed to download file. Status code: {response.status_code}")

            PyMuPDFReader = download_loader("PyMuPDFReader")
            loader = PyMuPDFReader()
            Documents = []

            count = 0
            for path in get_file_paths(f"./local_pdf_document_path/{domain_id}/{websiteId}/"):
                documents = loader.load_data(file_path=Path(path),metadata=False)
                Documents.extend(documents)
                print("===============================",documents)
                count+=1

            print("pdf_count-------------->",count)

            # documents = SimpleDirectoryReader(f"./local_pdf_document_path/{domain_id}/{websiteId}/").load_data()
            # db_path=f"embedded_docs"
            # db_path=f"embedded_article/{domain_id}/{websiteId}"pyth
            service_context = ServiceContext.from_defaults(embed_model=embed_model,llm = None,chunk_size=300)
            db = chromadb.PersistentClient(path=f"merged_embedded_article/{domain_id}/{websiteId}")
            try:
                db.delete_collection(name="quickstart")
            except:
                pass
            chroma_collection = db.create_collection("quickstart")
            vector_store = ChromaVectorStore(chroma_collection=chroma_collection)
            progress_data = {"websiteId":websiteId,"domainId":domain_id,"ext":ext,"progress":40}
            progress_data = json.dumps(progress_data)
            print("progress-------------------------------------------",40)
            print(progress_data)
            rc.rpush("webscrap_res_1",progress_data)

            storage_context = StorageContext.from_defaults(vector_store=vector_store)
            VectorStoreIndex.from_documents(Documents,storage_context=storage_context,
                                            service_context=service_context,
                                            show_progress=True)
            progress_data = {"websiteId":websiteId,"domainId":domain_id,"ext":ext,"progress":80}
            progress_data = json.dumps(progress_data)
            print("progress-------------------------------------------",80)
            print(progress_data)

            rc.rpush("webscrap_res_1",progress_data)
            
            
            print(f"embedded files saved in merged_embedded_article/{domain_id}/{websiteId} in folder")
            return "success" 
        
        elif extension == "csv":
            file_path = pdf_links
            file_name = file_path.split('/')[-1].split('.csv')[0]
            file_name = file_name.replace(" ","_")
            print(file_name)

            #Deleting the old downloaded path
            directory_path_del = f"./local_csv_document_path/{domain_id}/{websiteId}/{file_name}.csv"
            # try:
            #     shutil.rmtree(directory_path_del)
            #     print(f"Directory '{directory_path_del}' and its contents deleted successfully.")
            # except Exception as e:
            #     print(f"Error occurred: {e}")
            try:
                os.remove(directory_path_del)
            except Exception as e:
                print(e)


            #creating new downloading path and downloading the csv
            local_file_path = f"./local_csv_document_path/{domain_id}/{websiteId}/{file_name}.csv"
            os.makedirs(os.path.dirname(local_file_path), exist_ok=True) 
  
            print(local_file_path)
            response = requests.get(file_path)
            if response.status_code == 200:
                with open(local_file_path, 'wb') as file:
                    file.write(response.content)
                print(f"File downloaded successfully to {local_file_path}")
            else:
                print(f"Failed to download file. Status code: {response.status_code}")


            #=============================checking encoding====================================#
            
            try:       
                detector = UniversalDetector()

                # Open the file in binary mode to read its contents
                with open(local_file_path, 'rb') as file:
                    for line in file:
                        detector.feed(line)
                        if detector.done:
                            break

                detector.close()

                print(detector.result)
                encoding  = detector.result
            except:
                print("\nencoding detection failed\n")
            delimiter1 = ","
            try:
                with open(local_file_path) as f1:
                    firstline = f1.readline()
                    delimiter1 = detect(firstline)
            except:
                print("Cannot find delimiter")

            #==================================Variation=======================================
            try:
                print("------------1")
                vdf = pd.read_csv(local_file_path,encoding=encoding["encoding"],sep=delimiter1)
            except:
                print("------------2")

                vdf = pd.read_csv(local_file_path,encoding="unicode_escape",sep=delimiter1)

            print("vdf length ============",len(vdf))
            vdf = vdf.dropna()

            print("vdf length ---------------",len(vdf))
            columns = list(vdf)
            if len(columns) > 2:
                return '''The uploaded file contains more than two columns. Please ensure that the first row of your CSV file is designated as the header row, with "Question" as the header for the first column and "Answer" as the header for the second column. Kindly re-upload the file.'''

            question_col = columns[0]
            answer_col = columns[1]



            question_list = vdf[question_col].to_list()
            answer_list = vdf[answer_col].to_list()

            asyncio.run(get_variation(question_list,answer_list,websiteId,domain_id,ext,company_name,company_type))

            dict_id = str(domain_id)+"_"+websiteId
            print(len(DataDict.user_data[dict_id]["question"]),"-------")
            print(len(DataDict.user_data[dict_id]["answer"]),"-------")

            df_final =pd.DataFrame({"Question":DataDict.user_data[dict_id]["question"],"Answer":DataDict.user_data[dict_id]["answer"]})
            df_final.columns = ["Question","Answer"]
            directory_path_del = f"./variation_csv_document_path/{domain_id}/{websiteId}/{file_name}_variation.csv"
            # try:
            #     shutil.rmtree(directory_path_del)
            #     print(f"Directory '{directory_path_del}' and its contents deleted successfully.")
            # except Exception as e:
            #     print(f"Error occurred: {e}")
            try:
                os.remove(directory_path_del)
            except:
                pass

            variation_path = f"./variation_csv_document_path/{domain_id}/{websiteId}/{file_name}_variation.csv"
            os.makedirs(os.path.dirname(variation_path), exist_ok=True) 

            df_final.to_csv(variation_path,index= False)

            #=======================================================================================

            folder_path = f"./variation_csv_document_path/{domain_id}/{websiteId}"
            # Initialize an empty list to store individual DataFrames
            dfs = []
            # Loop through each file in the folder
            for file in os.listdir(folder_path):
                file_path = os.path.join(folder_path, file)
                if file.endswith('.csv') and file != file_name:
                    try:
                        detector = UniversalDetector()
                        # Open the file in binary mode to read its contents
                        with open(file_path, 'rb') as file:
                            for line in file:
                                detector.feed(line)
                                if detector.done:
                                    break

                        detector.close()

                        print(detector.result)
                        encoding  = detector.result

                    except:
                        print("\nencoding detection failed\n")

                    delimiter1 = ","
                    try:
                        with open(file_path) as f1:
                            firstline = f1.readline()
                            delimiter1 = detect(firstline)
                    except:
                        print("Cannot find delimiter")  # Get the full file path  # Check if the file is a CSV file
                      # Get the full file path
                    try:
                        df = pd.read_csv(file_path,encoding=encoding["encoding"],sep=delimiter1)
                    except:
                        df = pd.read_csv(file_path,encoding="unicode_escape",sep=delimiter1) # Read the CSV file into a DataFrame
                    dfs.append(df)  # Append the DataFrame to the list


            new_csv_dataframe = pd.read_csv(variation_path)
            # Concatenate all DataFrames in the list into a single DataFrame
            print(type(new_csv_dataframe))
            dfs = [new_csv_dataframe]+dfs
            print(dfs)
            combined_df = pd.concat(dfs, ignore_index=True,axis=0)
            print(combined_df.head())
            combined_df =  combined_df.drop_duplicates(subset=combined_df.columns[0])
            # print(combined_df.head())

            merge_csv_path_file = f"./merge_csv_document_path/{domain_id}/{websiteId}/{domain_id}_{websiteId}_merged.csv"
            os.makedirs(os.path.dirname(merge_csv_path_file), exist_ok=True)
            combined_df.to_csv(merge_csv_path_file,index=False)

            try:
                detector = UniversalDetector()
                # Open the file in binary mode to read its contents
                with open(merge_csv_path_file, 'rb') as file:
                    for line in file:
                        detector.feed(line)
                        if detector.done:
                            break

                detector.close()

                print(detector.result)
                encoding  = detector.result

            except:
                print("\nencoding detection failed\n")

            delimiter1 = ","
            try:
                with open(file_path) as f1:
                    firstline = f1.readline()
                    delimiter1 = detect(firstline)
            except:
                print("Cannot find delimiter")  # Get the full file path  # Check if the file is a CSV file
                # Get the full file path
            try:
                combined_df = pd.read_csv(merge_csv_path_file,encoding=encoding["encoding"],sep=delimiter1)
            except:
                combined_df = pd.read_csv(merge_csv_path_file,encoding="unicode_escape",sep=delimiter1) # Read the CSV file into a DataFrame

            combined_df.head()
            print(len(combined_df))
            columns = list(combined_df)
            print(columns)
            question_col = columns[0]
            print(question_col)
            answer_col = columns[1]
            print(answer_col)



            clean_question = []
            for i in range(len(combined_df['Question'])):
                new_string = re.sub(r'[^A-Za-z0-9]', ' ', str(combined_df[question_col][i]).lower())
                new_string = re.sub(r"\s+", ' ', new_string)
                # new_string = str(i).replace("?","")
                clean_question.append(new_string)

            qn_embeddings = model.encode(clean_question)
            directory_name = f"pkl_live_server/{domain_id}/{websiteId}"

            # old_pkl_dir = f"pkl_live_server/{domain_id}/{websiteId}"
            # try:
            #     shutil.rmtree(old_pkl_dir)
            #     print(f"Directory '{old_pkl_dir}' and its contents deleted successfully.")
            # except Exception as e:
            #     print(f"Error occurred: {e}")
            

            #Deleting old pkl folder
            query_path = f"pkl_live_server/{domain_id}/{websiteId}/query_embedding.pkl"
            ans_path = f"pkl_live_server/{domain_id}/{websiteId}/Answer.pkl"

            if os.path.exists(query_path):
                os.remove(query_path)
            if os.path.exists(ans_path):
                os.remove(ans_path)

            os.makedirs(os.path.dirname(query_path), exist_ok=True)
            os.makedirs(os.path.dirname(ans_path), exist_ok=True)
            pickle.dump(qn_embeddings, open(f'{directory_name}/query_embedding.pkl', 'wb'))
            pickle.dump(combined_df[answer_col], open(f'{directory_name}/Answer.pkl', 'wb'))
            print(f"Succesfully embeddings are Stored in pkl_live_server/{domain_id}/{websiteId}")
            return "success"
            
        else:
            print("failure!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
            local_csv_path = f"./local_csv_document_path/{domain_id}/{websiteId}/{file_name}.csv"
            variation_path = f"./variation_csv_document_path/{domain_id}/{websiteId}/{file_name}_variation.csv"
            if os.path.exists(local_csv_path):
                os.remove(local_csv_path)
            if os.path.exists(variation_path):
                os.remove(variation_path)
            return "failure"

    except KeyboardInterrupt as k:
        print(k)
        exit()

    except Exception as e:
        print(e)
        local_csv_path = f"./local_csv_document_path/{domain_id}/{websiteId}/{file_name}.csv"
        variation_path = f"./variation_csv_document_path/{domain_id}/{websiteId}/{file_name}_variation.csv"
        if os.path.exists(local_csv_path):
            os.remove(local_csv_path)
        if os.path.exists(variation_path):
            os.remove(variation_path)
        return "failure"

@app.post("/document/")
def parse_chat(docs:Docs):
    try:
        start_time = time()
        pdf_links=docs.pdf_links
        domain_id =docs.domainId
        websiteId=docs.websiteId
        ext = docs.ext
        company_name = docs.companyName
        company_type = docs.companyType
        print("pdf linlks ---------------------------",pdf_links)
        print("Domain Id-----------------------",domain_id)
        print("website Id-----------------------",websiteId)
        print("ext Id-----------------------",ext)
        print("company name-----------------------",company_name)
        print("company type----------------------",company_type)


        dict_id = str(domain_id)+"_"+websiteId
        DataDict.user_data[dict_id] = {"question":[],"answer":[]}
        # embeddings = get_embeddings()
        data=pdf_embeddings(pdf_links,websiteId,domain_id,ext,company_name,company_type)
        final_data={"websiteId":websiteId,"domainId":domain_id,'message':data,"ext":ext}
        end_time = time()
        del DataDict.user_data[dict_id]
        print("Total Time taken -----> ",(end_time-start_time))
        current_date_time = datetime.datetime.now()
        print(f"Current Date and Time domain : {domain_id} webide_id : {websiteId}:", current_date_time)
        progress_data = {"websiteId":websiteId,"domainId":domain_id,"ext":ext,"progress":100}
        progress_data = json.dumps(progress_data)
        rc.rpush("webscrap_res_1",progress_data)
        return final_data
    
    except KeyboardInterrupt as k:
        print(k)
        exit()
    except Exception as e:
        print(e)
        file_path = pdf_links
        file_name = file_path.split('/')[-1].split('.csv')[0]
        file_name = file_name.replace(" ","_")
        print(file_name)
        current_date_time = datetime.datetime.now()
        print(f"Current Date and Time domain : {domain_id} webide_id : {websiteId}:", current_date_time)
        local_csv_path = f"./local_csv_document_path/{domain_id}/{websiteId}/{file_name}.csv"
        variation_path = f"./variation_csv_document_path/{domain_id}/{websiteId}/{file_name}_variation.csv"
        if os.path.exists(local_csv_path):
            os.remove(local_csv_path)
        if os.path.exists(variation_path):
            os.remove(variation_path)
        print("failure!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        return "failure"
   

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=7002)




